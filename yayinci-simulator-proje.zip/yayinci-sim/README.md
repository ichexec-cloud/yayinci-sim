# 📺 Yayıncı Simülatör — Kurulum Rehberi

Telefona tam ekran uygulama olarak kurmak için 2 yöntem var.

---

## 🚀 YÖNTEM 1: Vercel (Önerilen — 5 dakika)

### Adım 1 — GitHub'a yükle
1. [github.com](https://github.com) → hesap aç (ücretsiz)
2. "New repository" → isim: `yayinci-sim` → Create
3. "uploading an existing file" linkine tıkla
4. Bu klasördeki **tüm dosyaları** sürükle-bırak
5. "Commit changes" → tıkla

### Adım 2 — Vercel'e deploy et
1. [vercel.com](https://vercel.com) → "Sign up with GitHub"
2. "New Project" → `yayinci-sim` reposunu seç
3. Framework: **Create React App** seç
4. "Deploy" → tıkla
5. ✅ 2 dakikada link hazır! `https://yayinci-sim-xxx.vercel.app`

### Adım 3 — Telefona kur
**iPhone (Safari):**
1. Linki Safari'de aç
2. Alt çubukta Paylaş butonu → "Ana Ekrana Ekle"
3. "Ekle" → uygulama gibi tam ekran açılır!

**Android (Chrome):**
1. Linki Chrome'da aç
2. Sağ üst ⋮ → "Ana ekrana ekle"
3. Kur → tam ekran oynanır!

---

## 🚀 YÖNTEM 2: Netlify (Drag & Drop — 3 dakika)

1. `npm install && npm run build` çalıştır (Node.js gerekli)
2. [netlify.com](https://netlify.com) → "Deploy manually"
3. `build/` klasörünü sürükle-bırak
4. ✅ Anında link! Telefona Ana Ekrana Ekle

---

## 💻 Yerel çalıştırma (bilgisayarda test)

```bash
# Node.js kurulu olmalı: nodejs.org
npm install
npm start
# → http://localhost:3000 açılır
```

---

## 📁 Dosya Yapısı

```
yayinci-sim/
├── public/
│   ├── index.html      # Ana HTML
│   ├── manifest.json   # PWA ayarları
│   └── sw.js           # Offline destek
├── src/
│   ├── index.js        # Giriş noktası
│   └── App.jsx         # Oyunun tüm kodu
└── package.json        # Bağımlılıklar
```

---

## ⚠️ Not

Oyundaki AI chat özelliği (Claude API) internet bağlantısı gerektirir.
Diğer her şey offline çalışır.
