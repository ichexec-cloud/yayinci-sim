import { useState, useEffect, useRef, useCallback } from "react";

// ── CONSTANTS ─────────────────────────────────────────────────────────────────
const PLAT = [
  { id:"youtube", name:"YouTube", color:"#FF0000", icon:"▶", adRate:1.4 },
  { id:"kick",    name:"Kick",    color:"#53FC18", icon:"⚡", adRate:0.7 },
];
const CATS = [
  { id:"gaming",   name:"Oyun",       emoji:"🎮", base:900,  ret:1.1  },
  { id:"vlog",     name:"Vlog",       emoji:"📷", base:500,  ret:1.0  },
  { id:"tutorial", name:"Eğitim",     emoji:"📚", base:650,  ret:1.2  },
  { id:"music",    name:"Müzik",      emoji:"🎵", base:700,  ret:0.9  },
  { id:"comedy",   name:"Komedi",     emoji:"😂", base:950,  ret:0.95 },
  { id:"tech",     name:"Teknoloji",  emoji:"💻", base:680,  ret:1.15 },
];
const EDIT_STEPS = [
  {id:"trim",       name:"Ham Kesme",       icon:"✂️", time:3,  q:8 },
  {id:"cuts",       name:"Hızlı Kesimler",  icon:"⚡", time:5,  q:15},
  {id:"color",      name:"Renk Ayarı",      icon:"🎨", time:8,  q:18},
  {id:"trans",      name:"Geçişler",         icon:"🔀", time:6,  q:12},
  {id:"bgm",        name:"Arkaplan Müzik",  icon:"🎵", time:7,  q:16},
  {id:"subs",       name:"Altyazı",         icon:"💬", time:10, q:20},
  {id:"thumb",      name:"Thumbnail",       icon:"🖼️", time:12, q:30},
  {id:"vfx",        name:"Efekt/Overlay",   icon:"✨", time:14, q:25},
  {id:"end",        name:"Son Ekran",        icon:"📌", time:4,  q:10},
  {id:"chap",       name:"Bölümler",         icon:"📋", time:5,  q:8 },
];
const ISPD = [
  {id:"dial",    name:"56k",       upload:0.05, cost:10,  upT:180, sq:"144p"},
  {id:"adsl",    name:"ADSL 8M",   upload:0.5,  cost:30,  upT:90,  sq:"480p"},
  {id:"f25",     name:"Fiber 25M", upload:5,    cost:60,  upT:30,  sq:"720p"},
  {id:"f100",    name:"Fiber 100M",upload:20,   cost:100, upT:12,  sq:"1080p"},
  {id:"f500",    name:"Fiber 500M",upload:100,  cost:200, upT:5,   sq:"1440p"},
  {id:"gig",     name:"Gigabit",   upload:500,  cost:400, upT:2,   sq:"4K"},
];
const SPONSORS = [
  {id:"vpn",    name:"VPN Servisi",    pay:500,   min:1000,   icon:"🔒"},
  {id:"energy", name:"Enerji İçeceği", pay:800,   min:5000,   icon:"⚡"},
  {id:"hdset",  name:"Gaming Kulaklık",pay:1500,  min:10000,  icon:"🎧"},
  {id:"mon",    name:"Oyun Monitörü",  pay:2500,  min:25000,  icon:"🖥️"},
  {id:"phone",  name:"Akıllı Telefon", pay:5000,  min:50000,  icon:"📱"},
  {id:"car",    name:"Araba Markası",  pay:15000, min:200000, icon:"🚗"},
];

// ── USERNAMES ──────────────────────────────────────────────────────────────────
const PRE=["Kral","Pro","Dark","Night","Shadow","Fire","Storm","Wolf","Dragon","Turbo","Ultra","Ghost","Ninja","Cyber","Nova","Titan","Apex","Blaze","Frost","Echo","Raven","Clutch","Snipe","Rush","Pixel"];
const SUF=["_TR","Gaming","_YT","_TV","47","99","_gg","PvP","Fan","Pro","_can","_han","2025","123","_x","HD","4K"];
const FN =["Ahmet","Mehmet","Ali","Mustafa","Emre","Burak","Selim","Fatih","Kemal","Mert","Ozan","Enes","Berk","Arda","Taha","Yusuf","Eren","Uğur","Caner","Deniz","Elif","Zeynep","Selin","Büşra","Merve","Sude"];
const gUN=()=>{const r=Math.random();if(r<.35)return PRE[~~(r*100%PRE.length)]+SUF[~~(Math.random()*SUF.length)];if(r<.65)return FN[~~(Math.random()*FN.length)]+"_"+(~~(Math.random()*9000)+1000);return FN[~~(Math.random()*FN.length)]+SUF[~~(Math.random()*SUF.length)];};

// ── CHAT DATA ──────────────────────────────────────────────────────────────────
const CONVOS=[
  [["lan bu oyun bugün lag mı yapıyor?"],["bende de öyle oldu ya","sunucu sorunu galiba","evet bende de kasıyor"]],
  [["setup ne kadar etti sizce"],["20-30k arası","PC'si güçlü belli ki","RTX var belli"]],
  [["sub olmaya değer mi?"],["bence değer","emotes güzel var","aylık az para zaten"]],
  [["bu bölüm nasıl geçilir ya"],["arkadan git","çevre duvarını kullan","ben de takıldım orada"]],
  [["türkçe yayıncı çok az kaliteli"],["bu iyi bence","katılıyorum","zaten bu yüzden buradayım"]],
  [["bugün kadro var mı"],["sanmıyorum yalnız bugün","duo var belki","kadro olursa daha eğlenceli"]],
  [["klip aldım o sahneyi"],["paylaş discorda","ben de aldım","epic sahne gerçekten"]],
  [["hangi kulaklık kullanıyor acaba"],["hyper x gibi","bence steelseries","sormak lazım"]],
];
const SINGLES=["gg","pog","lul","kekw","aynen","iyi yayın","devam et","harika","kral","efsane","PogChamp","KEKW","LUL","🔥🔥","💪","👑","😂😂","bunu beklemiyordum","lan be","ya cidden","clutch","imkansız","tanrı gibi","nasıl yaptı bunu","türkçe chat aktif","naber","selam herkese","iyi günler","hype hype","efsane bro","peki ya","omg","vay be","ya cidden mi","dur dur dur","OMEGALUL"];
const DON_POOL=[
  {amount:50,  msg:"Kral yayın! Devam et 💪"},
  {amount:100, msg:"En iyi yayıncı seninsin!"},
  {amount:25,  msg:"PogChamp PogChamp"},
  {amount:200, msg:"Yıllardır izliyorum 🙏"},
  {amount:500, msg:"GOD TIER PLAYER"},
  {amount:75,  msg:"Seni seviyoruz!"},
  {amount:1000,msg:"HYPE HYPE HYPE 🔥🔥🔥"},
  {amount:10,  msg:"küçük bir destek :)"},
  {amount:150, msg:"Bu sahne için bağış!"},
  {amount:300, msg:"Çok güzel yayın, sağ ol"},
];
const DISC_PRE=["yayın ne zaman?","bugün yayın var mı?","heyecanlandım ya","hazır bekliyorum","çay koydum 😄","arkadaşıma da söyledim","geçen efsaneydi","bugün kadrolu mu","yayın açılsın artık","laptop başındayım","bildirim açık","kim var burada","naber herkese","selam fanlar","ben de bekliyorum","kafam yayında"];
const DISC_LIVE=["YAYINDAAAA 🔥","geldim!","sa sa naber","hadi gidiyoruz","koştum geldim 😂","bekledim sonunda","hayırlı yayınlar","açıldı mı bekliyordum","iyi yayınlar kral","gireceğim hemen"];
const FAN_NAMES=["KralFan_01","TürkGameFan","Ahmet_izler","NightWatch_TR","ProFanatic","Emre_Gaming","SteelFan99","DarkFollower","Clutch_Can","NovaTR","Mert_Fan","Ali_Takip"];

// ── GAME EVENTS ────────────────────────────────────────────────────────────────
const GAME_EVENTS={
  died:  {icon:"💀",title:"ÖLDÜ!",    sub:"KÖTÜ",    color:"#ff4444",chatMsgs:["lan nasıl öldün ya","KEKW KEKW","ahahaha","bekliyordum bunu","OMEGALUL","lul lul lul","nasıl ya o basitti","bro..."]},
  drop:  {icon:"🏆",title:"DROP!",    sub:"EFSANE",  color:"#ffd700",chatMsgs:["DROPPPPPP 🏆","efsane drop","kral aldı","PogChamp PogChamp PogChamp","drop drop drop 🔥","ya ne iyisin","tanrı","GOD TIER"]},
  clutch:{icon:"⚔️",title:"CLUTCH!",  sub:"1vs5",    color:"#ff6b35",chatMsgs:["CLUTCH 😱","NASIL YA","bro imkansız","PogChamp","ya bu mümkün değil","1v5 clutch geldii","efsane","kral oynadı"]},
  funny: {icon:"😂",title:"KOMIK!",   sub:"LOL",     color:"#ffd93d",chatMsgs:["KEKW KEKW KEKW","ahahaha","çok güldüm ya","LUL LUL","ölüyorum 😂","bro ne yaptın","OMEGALUL","klip aldım bunu"]},
  rage:  {icon:"😡",title:"RAGE!",    sub:"TILT",    color:"#ff0088",chatMsgs:["TILT OLDU","bro sakin ol","KEKW rage modu","hahahaha","tetik çöktü","bro masayı kır","mola ver","lul lul"]},
};

// ── AI CHAT REACTIONS ──────────────────────────────────────────────────────────
// Context-aware reactions from Claude API
async function getAiChatReaction(context) {
  try {
    const SYSPROMPT = "Sen bir canli yayin chat botusun. Yayincinin durumuna gore chatciler adina 3-5 kisa, gercekci Turkce yorum uret, her biri yeni satirda. Argoda konus (bro, ya, lan, gg, PogChamp, KEKW vb). Emoji kullan. Sadece mesajlari yaz, baska aciklama yok.";
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 120,
        system: SYSPROMPT,
        messages: [{ role: "user", content: "Yayin durumu: " + context + ". Chatcilerin tepkileri:" }]
      })
    });
    const d = await res.json();
    if (d.content && d.content[0]) {
      return d.content[0].text.trim().split("\n").filter(l => l.trim()).slice(0, 5);
    }
  } catch(e) {}
  return null;
}

// ── HELPERS ────────────────────────────────────────────────────────────────────
const COLORS=["#ff6b6b","#ffd93d","#6bcb77","#4d96ff","#c77dff","#ff9f43","#ee5a24","#0abde3","#ff6b81","#a29bfe","#fd79a8","#fdcb6e","#55efc4","#81ecec","#74b9ff"];
const rC=()=>COLORS[~~(Math.random()*COLORS.length)];
const fmt=n=>n>=1e6?(n/1e6).toFixed(1)+"M":n>=1000?(n/1000).toFixed(1)+"K":Math.floor(n).toString();
const fmtM=n=>"₺"+Math.abs(n).toFixed(2);
const fmtT=s=>{const h=~~(s/3600),m=~~((s%3600)/60),sc=s%60;return h>0?`${h}:${String(m).padStart(2,"0")}:${String(sc).padStart(2,"0")}`:`${String(m).padStart(2,"0")}:${String(sc).padStart(2,"0")}`;};
const gKey=()=>{const c="abcdefghijklmnopqrstuvwxyz0123456789";let k="";for(let i=0;i<32;i++){if(i>0&&i%8===0)k+="-";k+=c[~~(Math.random()*c.length)];}return k.toUpperCase();};
const calcViews=(cat,q,subs,spd)=>{const C=CATS.find(c=>c.id===cat),S=ISPD.find(s=>s.id===spd);return Math.floor(C.base*(1+q/250)*(1+subs/60000)*C.ret*(S.upT>60?.6:1)*(.75+Math.random()*.5));};
const gCmts=(views)=>{const P=["Bu video müthişti!","Harika içerik 🙏","Aboneliğe değer!","Daha fazla istiyoruz!","İzlemeye doyamadım","Arkadaşlarıma önerdim","Yıllardır izliyorum 😅","Bildirim gelince tıkladım","Beklentimin üstünde","Montaj çok iyiydi","Thumbnail güzeldi","Bu kanalı geç buldum","Devam et!","Sahne komikti 😂","Yeni video ne zaman?","Bu en iyi videon!"];const U=Array.from({length:14},gUN);return Array.from({length:Math.min(4+~~(views/250),18)},(_,i)=>({id:i,user:U[i%U.length],color:rC(),text:P[~~(Math.random()*P.length)],likes:~~(Math.random()*300),pinned:false,hearted:false,time:`${~~(Math.random()*23)}:${String(~~(Math.random()*59)).padStart(2,"0")}`}));};

const INIT=()=>({
  channelName:"",platform:"youtube",streamKey:gKey(),
  subscribers:0,kickSubs:0,totalViews:0,money:500,day:1,tickStatus:false,
  videos:[],ytComments:{},
  isRecording:false,recProg:0,recCat:"gaming",recMins:10,rawVid:null,
  editedVid:null,
  isUploading:false,upProg:0,
  isLive:false,livePlat:"kick",liveV:0,liveSecs:0,
  liveChat:[],liveBanned:[],liveTout:[],liveDons:[],
  internet:"f25",
  activeSponsors:[],sponsorOffers:[SPONSORS[0]],
  notifs:[],strikes:0,tab:"main",
  ss:{vol:80,mic:75,game:70,music:40,camera:"Kamera 1 (720p)",micDev:"Varsayılan Mikrofon",src:"Masaüstü Yakalama",res:"1080p60",bit:6000},
  discMsgs:[],
  fanUsers:Array.from({length:10},()=>({name:FAN_NAMES[~~(Math.random()*FAN_NAMES.length)],color:rC()})),
});

// ── APP ────────────────────────────────────────────────────────────────────────
export default function App(){
  const [gs,setGs]=useState(null);
  const [setup,setSetup]=useState({name:"",platform:"youtube",internet:"f25",show:true});
  // modals
  const [streamSetup,setStreamSetup]=useState(false);
  const [ssLocal,setSsLocal]=useState(null);
  const [liveScreen,setLiveScreen]=useState(false);
  const [showLiveSettings,setShowLiveSettings]=useState(false);
  const [recModal,setRecModal]=useState(false);
  const [editModal,setEditModal]=useState(false);
  const [upModal,setUpModal]=useState(false);
  const [renameModal,setRenameModal]=useState(false);
  const [cmtModal,setCmtModal]=useState(null);
  const [discOpen,setDiscOpen]=useState(false);
  // edit
  const [editDone,setEditDone]=useState([]);
  const [editActive,setEditActive]=useState(null);
  const [editTL,setEditTL]=useState([]);
  // upload
  const [upTitle,setUpTitle]=useState("");
  const [upDesc,setUpDesc]=useState("");
  // live
  const [livePlat,setLivePlat]=useState("kick");
  const [chatIn,setChatIn]=useState("");
  const [donPop,setDonPop]=useState(null);
  const [subPop,setSubPop]=useState(null);
  const [aiPop,setAiPop]=useState(null);
  const [gameEvBanner,setGameEvBanner]=useState(null);
  const [gameEvIcon,setGameEvIcon]=useState(null);
  const [chatW,setChatW]=useState(300);
  const [chatCollapsed,setChatCollapsed]=useState(false);
  const prevChatW=useRef(300);
  const [isDrag,setIsDrag]=useState(false);
  const [activeScene,setActiveScene]=useState("game");
  const [endConfirm,setEndConfirm]=useState(false);
  // record
  const [recCat,setRecCat]=useState("gaming");
  const [recMins,setRecMins]=useState(15);
  const [newName,setNewName]=useState("");
  const [discIn,setDiscIn]=useState("");

  const chatRef=useRef(null);
  const dcRef=useRef(null);
  const liveRef=useRef(null);
  const recRef=useRef(null);
  const upRef=useRef(null);
  const dX=useRef(0),dW=useRef(0);
  const userPool=useRef([]);

  const push=useCallback((msg,type="info")=>{
    setGs(g=>{if(!g)return g;return{...g,notifs:[{id:Date.now()+Math.random(),msg,type},...g.notifs].slice(0,5)};});
  },[]);

  // ── SETUP ──
  function startGame(){
    if(!setup.name.trim())return;
    const g=INIT();
    g.channelName=setup.name.trim();
    g.platform=setup.platform;
    g.internet=setup.internet;
    const msgs=[];
    for(let i=0;i<12;i++){
      const f=g.fanUsers[~~(Math.random()*g.fanUsers.length)];
      msgs.push({id:i,user:f.name,color:f.color,text:DISC_PRE[~~(Math.random()*DISC_PRE.length)],time:new Date(Date.now()-1000*(12-i)*65).toLocaleTimeString("tr-TR",{hour:"2-digit",minute:"2-digit"})});
    }
    g.discMsgs=msgs;
    userPool.current=Array.from({length:80},()=>({name:gUN(),color:rC(),isSub:Math.random()<.1}));
    setGs(g);
    setSetup(s=>({...s,show:false}));
  }

  // ── RECORD ──
  function startRec(){
    setRecModal(false);
    setGs(g=>({...g,isRecording:true,recProg:0,recCat,recMins}));
    let p=0;
    recRef.current=setInterval(()=>{
      p=Math.min(p+100/(recMins*1.5),100);
      setGs(g=>({...g,recProg:p}));
      if(p>=100){clearInterval(recRef.current);setGs(g=>({...g,isRecording:false,rawVid:{cat:recCat,mins:recMins,id:Date.now()}}));push(`🎬 ${recMins} dk ham video hazır!`,"success");}
    },120);
  }

  // ── EDIT ──
  function openEdit(){setEditDone([]);setEditActive(null);setEditTL([]);setEditModal(true);}
  function doStep(sid){
    if(editActive||editDone.includes(sid))return;
    const st=EDIT_STEPS.find(s=>s.id===sid);
    setEditActive(sid);
    setTimeout(()=>{
      setEditActive(null);
      setEditDone(p=>[...p,sid]);
      setEditTL(p=>[...p,{sid,time:new Date().toLocaleTimeString("tr-TR",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}]);
    },st.time*300);
  }
  function finalEdit(){
    if(!editDone.length){push("En az 1 adım!","error");return;}
    const q=editDone.reduce((s,id)=>s+(EDIT_STEPS.find(e=>e.id===id)?.q||0),10);
    setEditModal(false);
    setGs(g=>({...g,rawVid:null,editedVid:{...g.rawVid,quality:q}}));
    push(`✅ Düzenleme tamam! Kalite: ${q}`,"success");
  }

  // ── UPLOAD ──
  function startUp(){
    if(!upTitle.trim()){push("Başlık gir!","error");return;}
    if(gs.strikes>=3){push("🚫 3 strike! Askıya alındı.","error");setUpModal(false);return;}
    const spd=ISPD.find(s=>s.id===gs.internet);
    setUpModal(false);
    setGs(g=>({...g,isUploading:true,upProg:0}));
    let p=0;
    upRef.current=setInterval(()=>{
      p=Math.min(p+100/(spd.upT*8),100);
      setGs(g=>({...g,upProg:p}));
      if(p>=100){
        clearInterval(upRef.current);
        setGs(g=>{
          const pl=PLAT.find(x=>x.id===g.platform);
          const views=calcViews(g.editedVid.cat,g.editedVid.quality,g.subscribers,g.internet);
          const ns=~~(views*(.04+Math.random()*.08));
          const earn=views*pl.adRate*.002;
          const vid={id:g.editedVid.id,title:upTitle,cat:g.editedVid.cat,views,quality:g.editedVid.quality,day:g.day,earnings:earn,likes:~~(views*.07),platform:g.platform};
          const ts=g.subscribers+ns;
          let tick=g.tickStatus;
          if(ts>=100000&&!tick){tick=true;setTimeout(()=>push("🎉 100K! Gümüş Buton + Tik!","special"),300);}
          let offers=[...g.sponsorOffers];
          SPONSORS.forEach(sp=>{if(ts>=sp.min&&!g.activeSponsors.find(a=>a.id===sp.id)&&!offers.find(o=>o.id===sp.id))offers.push(sp);});
          return{...g,isUploading:false,upProg:100,editedVid:null,videos:[vid,...g.videos],subscribers:ts,totalViews:g.totalViews+views,money:g.money+earn,tickStatus:tick,ytComments:{...g.ytComments,[vid.id]:gCmts(views)},sponsorOffers:offers};
        });
        push("📤 Yüklendi!","success");
      }
    },80);
  }

  // ── STREAM SETUP ──
  function openStreamSetup(){setSsLocal({...gs.ss,platform:livePlat});setStreamSetup(true);}
  function applyStream(){
    const pl=ssLocal.platform||livePlat;
    setGs(g=>({...g,ss:ssLocal,livePlat:pl}));
    setLivePlat(pl);
    setStreamSetup(false);
    doStartLive(pl,ssLocal);
  }

  // ── LIVE ──
  function doStartLive(pl,ss){
    userPool.current=Array.from({length:80},()=>({name:gUN(),color:rC(),isSub:Math.random()<.1}));
    setGs(g=>{
      const greets=Array.from({length:4+~~(Math.random()*4)},(_,i)=>{
        const f=g.fanUsers[~~(Math.random()*g.fanUsers.length)];
        return{id:Date.now()+i,user:f.name,color:f.color,text:DISC_LIVE[~~(Math.random()*DISC_LIVE.length)],time:new Date().toLocaleTimeString("tr-TR",{hour:"2-digit",minute:"2-digit"}),isLive:true};
      });
      return{...g,isLive:true,livePlat:pl,liveV:Math.max(2,~~(g.subscribers*.015)),liveSecs:0,liveChat:[],liveDons:[],discMsgs:[...g.discMsgs,...greets].slice(-60)};
    });
    setLiveScreen(true);
    push("🔴 CANLI YAYIN!","special");

    liveRef.current=setInterval(()=>{
      setGs(g=>{
        if(!g.isLive)return g;
        const lp=PLAT.find(p=>p.id===g.livePlat);
        const newV=Math.max(1,g.liveV+~~((Math.random()-.35)*12));
        let money=g.money+newV*lp.adRate*.00015;
        let ks=g.kickSubs;
        let chat=[...g.liveChat];
        let dons=[...g.liveDons];

        // Volume-aware chat
        const volHigh=(g.ss.vol||80)>90||(g.ss.game||70)>88;
        const micHigh=(g.ss.mic||75)>85;
        const musHigh=(g.ss.music||40)>80;

        // Regular message
        const sender=userPool.current[~~(Math.random()*userPool.current.length)];
        if(!g.liveBanned.includes(sender.name)){
          let txt=SINGLES[~~(Math.random()*SINGLES.length)];
          // Context-aware overrides
          if(volHigh&&Math.random()<.4) txt=["ses çok yüksek","ses fazla ya","kulaklarım patladı","sesi biraz kıs","oyun sesi boğuyor","müzik sesi yüksek","bro ses aç bakalım değil kıs 😅"][~~(Math.random()*7)];
          if(micHigh&&Math.random()<.3) txt=["mikrofon çok yüksek","ses kıs mikrofonu","çok gürültü var","mikrofon patladı","mic çok bas","patlıyor mic","mic sesi azalt"][~~(Math.random()*7)];
          if(musHigh&&Math.random()<.3) txt=["müzik çok yüksek","arkaplan müziği baskın","müziği kıs","konuşmayı duymuyoruz","müzik mi yayın mı?"][~~(Math.random()*5)];
          chat=[...chat,{id:Date.now()+Math.random(),user:sender.name,color:sender.color,text:txt,banned:false,timedOut:g.liveTout.includes(sender.name),isSub:sender.isSub,isDon:false,isMod:false}];
        }

        // Conversation
        if(Math.random()<.45){
          const cv=CONVOS[~~(Math.random()*CONVOS.length)];
          const uA=userPool.current[~~(Math.random()*userPool.current.length)];
          const uB=userPool.current[~~(Math.random()*userPool.current.length)];
          chat=[...chat,{id:Date.now()+.1,user:uA.name,color:uA.color,text:cv[0][~~(Math.random()*cv[0].length)],banned:false,timedOut:false,isSub:uA.isSub,isDon:false,isMod:false}];
          if(!g.liveBanned.includes(uB.name))
            chat=[...chat,{id:Date.now()+.15,user:uB.name,color:uB.color,text:cv[1][~~(Math.random()*cv[1].length)],banned:false,timedOut:false,isSub:uB.isSub,isDon:false,isMod:false}];
        }

        // Donation
        if(Math.random()<.02){
          const don=DON_POOL[~~(Math.random()*DON_POOL.length)];
          const du=userPool.current[~~(Math.random()*userPool.current.length)];
          chat=[...chat,{id:Date.now()+1,user:du.name,color:"#ffd700",text:`💰 ${fmtM(don.amount)}: ${don.msg}`,isDon:true,amount:don.amount,banned:false,timedOut:false,isSub:true,isMod:false}];
          money+=don.amount;
          dons=[{...don,user:du.name,id:Date.now()},...dons].slice(0,12);
          setTimeout(()=>{setDonPop({...don,user:du.name});setTimeout(()=>setDonPop(null),5500);},50);
        }

        // Sub
        if(Math.random()<.033){
          const su=userPool.current[~~(Math.random()*userPool.current.length)];
          const tier=[1,1,1,2,2,3][~~(Math.random()*6)];
          chat=[...chat,{id:Date.now()+2,user:su.name,color:"#53FC18",text:`⭐ ${su.name} abone oldu! (Tier ${tier})`,isDon:false,isSub:true,banned:false,timedOut:false,isMod:false,isSubAlert:true}];
          ks+=1;money+=tier*15;
          setTimeout(()=>{setSubPop({user:su.name,tier});setTimeout(()=>setSubPop(null),3500);},50);
        }

        return{...g,liveV:newV,liveSecs:g.liveSecs+1,money,kickSubs:ks,liveChat:chat.slice(-120),liveDons:dons};
      });
    },1700);
  }

  function requestEndLive(){
    // Send farewell burst to chat then end
    const farewells=["bb herkese","görüşürüz!","iyi geceler","sağlıcakla kalın","bye bye chat 👋","bb bb bb","görüşmek üzere!","eyw herkese","güzel yayındı teşekkürler","bb chat, seviyorum sizi","hadi gidin artık 😄","kapatıyorum görüşürüz","bb! yeni yayında görüşürüz","gg wp herkese","sağlıcakla!"];
    const users=userPool.current;
    const burst=farewells.slice(0,6+~~(Math.random()*4)).map((txt,i)=>({
      id:Date.now()+i+Math.random(),user:users[~~(Math.random()*users.length)].name,
      color:rC(),text:txt,banned:false,timedOut:false,isSub:Math.random()<.2,isDon:false,isMod:false
    }));
    // Also add streamer farewell
    burst.push({id:Date.now()+99,user:"Sen",color:"#53FC18",text:"Görüşürüz! 👋",isMod:true,banned:false,timedOut:false,isSub:true,isDon:false});
    setGs(g=>({...g,liveChat:[...g.liveChat,...burst].slice(-120)}));
    setEndConfirm(false);
    setTimeout(()=>doEndLive(),1800);
  }

  function doEndLive(){
    clearInterval(liveRef.current);
    setGs(g=>{
      if(g.livePlat==="kick"){
        setTimeout(()=>{
          push("📤 VOD YouTube'a yükleniyor...","info");
          setTimeout(()=>{
            setGs(g2=>{
              const views=calcViews("gaming",40,g2.subscribers,g2.internet);
              const vid={id:Date.now(),title:"🔴 CANLI YAYIN VOD - Gun "+g2.day,cat:"gaming",views,quality:40,day:g2.day,earnings:views*1.4*.002,likes:~~(views*.06),platform:"youtube"};
              push("✅ VOD yuklendi! "+fmt(views)+" izlenme!","success");
              return{...g2,videos:[vid,...g2.videos],subscribers:g2.subscribers+~~(views*.04),totalViews:g2.totalViews+views,money:g2.money+vid.earnings,ytComments:{...g2.ytComments,[vid.id]:gCmts(views)}};
            });
          },2000);
        },500);
      }
      push("📺 Bitti! "+fmtT(g.liveSecs)+" surdu.","info");
      return{...g,isLive:false};
    });
    setLiveScreen(false);setShowLiveSettings(false);setActiveScene("game");setEndConfirm(false);
  }

  // ── GAME EVENT ──
  async function triggerGameEvent(evId){
    const ev=GAME_EVENTS[evId];
    if(!ev)return;
    setGameEvIcon(ev.icon);
    setGameEvBanner(ev);
    setTimeout(()=>setGameEvBanner(null),2500);
    setTimeout(()=>setGameEvIcon(null),4000);
    // Add burst of chat msgs
    const msgs=ev.chatMsgs;
    const users=userPool.current;
    const burst=msgs.map((txt,i)=>({id:Date.now()+i+Math.random(),user:users[~~(Math.random()*users.length)].name,color:rC(),text:txt,banned:false,timedOut:false,isSub:Math.random()<.15,isDon:false,isMod:false}));
    setGs(g=>({...g,liveChat:[...g.liveChat,...burst].slice(-120)}));

    // AI reaction
    const ctx=`Yayıncı "${evId==="died"?"öldü":evId==="drop"?"drop aldı":evId==="clutch"?"clutch yaptı":evId==="funny"?"komik bir şey oldu":"rage moduna girdi"}"`;
    const aiLines=await getAiChatReaction(ctx);
    if(aiLines&&aiLines.length){
      setAiPop(aiLines.join("\n"));
      setTimeout(()=>setAiPop(null),6000);
      const aiUsers=userPool.current;
      const aiMsgs=aiLines.map((txt,i)=>({id:Date.now()+100+i,user:aiUsers[~~(Math.random()*aiUsers.length)].name,color:rC(),text:txt,banned:false,timedOut:false,isSub:false,isDon:false,isMod:false,isAiReply:true}));
      setTimeout(()=>setGs(g=>({...g,liveChat:[...g.liveChat,...aiMsgs].slice(-120)})),800);
    }
  }

  // React to streamer chat with AI
  async function sendChat(){
    if(!chatIn.trim())return;
    const msg={id:Date.now(),user:gs.channelName+" (Sen)",color:"#53FC18",text:chatIn,isMod:true,banned:false,timedOut:false,isSub:true,isDon:false};
    setGs(g=>({...g,liveChat:[...g.liveChat,msg].slice(-120)}));
    const userMsg=chatIn;
    setChatIn("");
    // AI chat reaction to what streamer said
    if(Math.random()<.6){
      const aiLines=await getAiChatReaction(`Yayıncı chate şunu yazdı: "${userMsg}"`);
      if(aiLines){
        const users=userPool.current;
        setTimeout(()=>{
          setGs(g=>({...g,liveChat:[...g.liveChat,...aiLines.map((txt,i)=>({id:Date.now()+i+200,user:users[~~(Math.random()*users.length)].name,color:rC(),text:txt,banned:false,timedOut:false,isSub:Math.random()<.1,isDon:false,isMod:false,isAiReply:true}))].slice(-120)}));
        },1200);
      }
    }
  }

  function banUser(u){setGs(g=>({...g,liveChat:g.liveChat.map(m=>m.user===u?{...m,banned:true}:m),liveBanned:[...g.liveBanned,u]}));}
  function toutUser(u){
    setGs(g=>({...g,liveChat:g.liveChat.map(m=>m.user===u?{...m,timedOut:true}:m),liveTout:[...g.liveTout,u]}));
    setTimeout(()=>setGs(g=>({...g,liveTout:g.liveTout.filter(x=>x!==u),liveChat:g.liveChat.map(m=>m.user===u?{...m,timedOut:false}:m)})),30000);
  }

  // ── CHAT DRAG RESIZE ──
  function onDragStart(e){setIsDrag(true);dX.current=e.clientX;dW.current=chatW;}
  useEffect(()=>{
    if(!isDrag)return;
    const onM=e=>{const d=dX.current-e.clientX;setChatW(Math.max(200,Math.min(600,dW.current+d)));};
    const onU=()=>setIsDrag(false);
    window.addEventListener("mousemove",onM);window.addEventListener("mouseup",onU);
    return()=>{window.removeEventListener("mousemove",onM);window.removeEventListener("mouseup",onU);};
  },[isDrag]);

  // ── YT COMMENTS ──
  function togglePin(v,c){setGs(g=>({...g,ytComments:{...g.ytComments,[v]:g.ytComments[v].map(x=>x.id===c?{...x,pinned:!x.pinned}:{...x,pinned:false})}}));}
  function toggleHeart(v,c){setGs(g=>({...g,ytComments:{...g.ytComments,[v]:g.ytComments[v].map(x=>x.id===c?{...x,hearted:!x.hearted}:x)}}));}

  // ── RENAME ──
  function applyRename(){if(!newName.trim())return;const had=gs.tickStatus;setGs(g=>({...g,channelName:newName.trim(),tickStatus:false}));if(had)push("⚠️ Tik kaldırıldı!","error");else push("✅ İsim değişti!","success");setRenameModal(false);}

  // ── DISCORD FANS ──
  useEffect(()=>{
    if(!gs||liveScreen)return;
    const iv=setInterval(()=>{setGs(g=>{if(!g||Math.random()>.3)return g;const f=g.fanUsers[~~(Math.random()*g.fanUsers.length)];return{...g,discMsgs:[...g.discMsgs,{id:Date.now()+Math.random(),user:f.name,color:f.color,text:g.isLive?DISC_LIVE[~~(Math.random()*DISC_LIVE.length)]:DISC_PRE[~~(Math.random()*DISC_PRE.length)],time:new Date().toLocaleTimeString("tr-TR",{hour:"2-digit",minute:"2-digit"})}].slice(-60)};});},8000);
    return()=>clearInterval(iv);
  },[gs?.channelName,liveScreen]);

  function sendDisc(){if(!discIn.trim())return;setGs(g=>({...g,discMsgs:[...g.discMsgs,{id:Date.now(),user:g.channelName+" (Sen)",color:"#53FC18",text:discIn,time:new Date().toLocaleTimeString("tr-TR",{hour:"2-digit",minute:"2-digit"}),isMod:true}].slice(-60)}));setDiscIn("");}
  function nextDay(){setGs(g=>{const s=ISPD.find(x=>x.id===g.internet);return{...g,day:g.day+1,money:Math.max(0,g.money-s.cost/30)};});push(`📅 Gün ${gs.day+1}`,"info");}
  function accSponsor(sp){setGs(g=>({...g,money:g.money+sp.pay,activeSponsors:[...g.activeSponsors,sp],sponsorOffers:g.sponsorOffers.filter(s=>s.id!==sp.id)}));push(`💼 ${sp.name} +${fmtM(sp.pay)}`,"success");}

  useEffect(()=>{if(chatRef.current)chatRef.current.scrollTop=chatRef.current.scrollHeight;},[gs?.liveChat]);
  useEffect(()=>{if(dcRef.current)dcRef.current.scrollTop=dcRef.current.scrollHeight;},[gs?.discMsgs]);

  // ══ SETUP SCREEN ════════════════════════════════════════════════════════════
  if(setup.show)return(
    <div style={{minHeight:"100vh",background:"#0a0a0f",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Courier New',monospace",color:"#e0e0e0",padding:16}}>
      <div style={{width:"100%",maxWidth:460,background:"#111118",border:"2px solid #1a1a2e",borderRadius:4,padding:28}}>
        <div style={{textAlign:"center",marginBottom:28}}><div style={{fontSize:52,marginBottom:8}}>📺</div><h1 style={{fontSize:22,fontWeight:900,letterSpacing:4,color:"#fff",margin:0}}>YAYINCI SİMÜLATÖR</h1><p style={{color:"#333",fontSize:10,marginTop:6}}>Kariyerine başla</p></div>
        <label style={L}>KANAL İSMİ</label>
        <input value={setup.name} onChange={e=>setSetup(s=>({...s,name:e.target.value}))} onKeyDown={e=>e.key==="Enter"&&startGame()} placeholder="Kanal adın?" style={{...IN,marginBottom:16}} />
        <label style={L}>ANA PLATFORM</label>
        <div style={{display:"flex",gap:8,marginBottom:16}}>
          {PLAT.map(p=><button key={p.id} onClick={()=>setSetup(s=>({...s,platform:p.id}))} style={{flex:1,padding:12,background:setup.platform===p.id?p.color+"22":"#0d0d14",border:`2px solid ${setup.platform===p.id?p.color:"#1a1a2e"}`,borderRadius:2,color:"#fff",cursor:"pointer",fontFamily:"inherit"}}><div style={{fontSize:24}}>{p.icon}</div><div style={{fontSize:12,marginTop:3}}>{p.name}</div></button>)}
        </div>
        <label style={L}>İNTERNET HIZI</label>
        <select value={setup.internet} onChange={e=>setSetup(s=>({...s,internet:e.target.value}))} style={{width:"100%",background:"#0d0d14",border:"1px solid #1a1a2e",borderRadius:2,padding:"9px 10px",color:"#fff",fontFamily:"inherit",fontSize:12,outline:"none",marginBottom:22}}>
          {ISPD.map(s=><option key={s.id} value={s.id}>{s.name} ({s.sq}) — ₺{s.cost}/ay</option>)}
        </select>
        <button onClick={startGame} disabled={!setup.name.trim()} style={{width:"100%",padding:13,background:setup.name.trim()?"#e53e3e":"#1a1a1a",border:"none",color:setup.name.trim()?"#fff":"#333",cursor:setup.name.trim()?"pointer":"not-allowed",borderRadius:2,fontFamily:"inherit",fontSize:14,fontWeight:700,letterSpacing:3}}>BAŞLA ▶</button>
      </div>
    </div>
  );
  if(!gs)return null;
  const plat=PLAT.find(p=>p.id===gs.platform);
  const isp=ISPD.find(s=>s.id===gs.internet);

  // ══ STREAM SETUP SCREEN ══════════════════════════════════════════════════════
  if(streamSetup&&ssLocal)return(
    <div style={{minHeight:"100vh",background:"#0a0a0f",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Courier New',monospace",color:"#e0e0e0",padding:16}}>
      <div style={{width:"100%",maxWidth:580,background:"#111118",border:"2px solid #1a1a2e",borderRadius:4,padding:24,maxHeight:"95vh",overflowY:"auto"}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:20}}><span style={{fontSize:24}}>⚙️</span><div><h2 style={{margin:0,fontSize:16,fontWeight:900,letterSpacing:2}}>YAYIN AYARLARI</h2><p style={{margin:0,fontSize:10,color:"#444"}}>Yayına başlamadan önce ayarlarını yap</p></div></div>
        <SC2 title="🎯 Platform">
          <div style={{display:"flex",gap:8}}>
            {PLAT.map(p=><button key={p.id} onClick={()=>setSsLocal(s=>({...s,platform:p.id}))} style={{flex:1,padding:10,background:ssLocal.platform===p.id?p.color+"22":"#0d0d14",border:`2px solid ${ssLocal.platform===p.id?p.color:"#1a1a2e"}`,borderRadius:2,color:"#fff",cursor:"pointer",fontFamily:"inherit"}}><div style={{fontSize:20}}>{p.icon}</div><div style={{fontSize:11,marginTop:2}}>{p.name}</div></button>)}
          </div>
          {ssLocal.platform==="kick"&&<div style={{background:"#0a2d0a",border:"1px solid #1a5a1a",borderRadius:2,padding:8,marginTop:8,fontSize:10,color:"#4ade80"}}>✅ Kick yayınları YouTube'a otomatik yüklenir!</div>}
        </SC2>
        <SC2 title="🔑 Yayın Anahtarı">
          <div style={{background:"#0d0d14",border:"1px solid #1a1a2e",borderRadius:2,padding:8,fontSize:10,color:"#4ade80",letterSpacing:1,wordBreak:"break-all",marginBottom:6}}>{gs.streamKey}</div>
          <button onClick={()=>navigator.clipboard?.writeText(gs.streamKey).then(()=>push("📋 Kopyalandı!","success"))} style={BS("#1a1a2e","#333")}>📋 Kopyala</button>
        </SC2>
        <SC2 title="🎦 Kalite">
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div><label style={L}>ÇÖZÜNÜRLÜK</label><select value={ssLocal.res} onChange={e=>setSsLocal(s=>({...s,res:e.target.value}))} style={SEL}>{["144p","360p","480p","720p60","1080p60","1440p60","4K60"].map(r=><option key={r} value={r}>{r}</option>)}</select></div>
            <div><label style={L}>BİTRATE (kbps)</label><select value={ssLocal.bit} onChange={e=>setSsLocal(s=>({...s,bit:+e.target.value}))} style={SEL}>{[1000,2500,4000,6000,8000,12000,18000].map(b=><option key={b} value={b}>{b}</option>)}</select></div>
          </div>
          <div style={{marginTop:7,fontSize:9,color:"#444"}}>Upload hızın: <b style={{color:"#4ade80"}}>{isp.upload} Mbps</b> • Önerilen max bitrate: {isp.upload>100?"18000":isp.upload>20?"8000":isp.upload>5?"4000":"2500"} kbps</div>
        </SC2>
        <SC2 title="📷 Kamera & Mikrofon">
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
            <div><label style={L}>KAMERA</label><select value={ssLocal.camera} onChange={e=>setSsLocal(s=>({...s,camera:e.target.value}))} style={SEL}>{["Kamera Yok","Kamera 1 (720p)","Kamera 1 (1080p)","Telefon Kamerası","Harici 4K"].map(c=><option key={c} value={c}>{c}</option>)}</select></div>
            <div><label style={L}>MİKROFON</label><select value={ssLocal.micDev} onChange={e=>setSsLocal(s=>({...s,micDev:e.target.value}))} style={SEL}>{["Varsayılan Mikrofon","Headset Mikrofonu","USB Kondenser","Mikrofon Kapalı"].map(m=><option key={m} value={m}>{m}</option>)}</select></div>
          </div>
          <label style={L}>MİKROFON SESİ: {ssLocal.mic}%</label>
          <input type="range" min={0} max={100} value={ssLocal.mic} onChange={e=>setSsLocal(s=>({...s,mic:+e.target.value}))} style={{width:"100%",accentColor:"#4d96ff"}} />
        </SC2>
        <SC2 title="🎮 Kaynak">
          <select value={ssLocal.src} onChange={e=>setSsLocal(s=>({...s,src:e.target.value}))} style={{...SEL,marginBottom:0}}>
            {["Masaüstü Yakalama","Oyun Yakalama (Tam Ekran)","Pencere Yakalama","Sadece Kamera","Podcast Modu"].map(g=><option key={g} value={g}>{g}</option>)}
          </select>
        </SC2>
        <SC2 title="🔊 Ses Ayarları">
          {[{label:"ANA SES",key:"vol",color:"#4ade80"},{label:"OYUN SESİ",key:"game",color:"#ffd700"},{label:"MÜZİK",key:"music",color:"#c77dff"}].map(({label,key,color})=>(
            <div key={key} style={{marginBottom:10}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><label style={L}>{label}</label><span style={{fontSize:10,color:ssLocal[key]>85?"#ff8800":color}}>{ssLocal[key]}%</span></div>
              <input type="range" min={0} max={100} value={ssLocal[key]} onChange={e=>setSsLocal(s=>({...s,[key]:+e.target.value}))} style={{width:"100%",accentColor:color}} />
            </div>
          ))}
        </SC2>
        <SC2 title="🌐 İnternet">
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:5}}>
            {ISPD.map(s=><button key={s.id} onClick={()=>{const d=s.cost-isp.cost;if(d>gs.money){push("Bakiye yetersiz!","error");return;}setGs(g=>({...g,internet:s.id,money:g.money-d}));}} style={{padding:"7px 6px",background:gs.internet===s.id?"#0d1a2e":"#0d0d14",border:`1px solid ${gs.internet===s.id?"#2563eb":"#1a1a2e"}`,borderRadius:2,color:gs.internet===s.id?"#4ade80":"#777",cursor:"pointer",fontFamily:"inherit",fontSize:9,textAlign:"left"}}>
              <div style={{fontWeight:600}}>{s.name}</div><div style={{color:"#444"}}>{fmtM(s.cost)}/ay • {s.sq}</div>
            </button>)}
          </div>
        </SC2>
        <div style={{display:"flex",gap:8}}>
          <button onClick={()=>setStreamSetup(false)} style={{flex:1,padding:11,background:"#1a1a2e",border:"1px solid #333",color:"#888",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontSize:12}}>İptal</button>
          <button onClick={applyStream} style={{flex:3,padding:11,background:"#ff4444",border:"none",color:"#fff",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontWeight:700,fontSize:14,letterSpacing:2}}>🔴 YAYINA GİR</button>
        </div>
      </div>
    </div>
  );

  // ══ LIVE SCREEN ══════════════════════════════════════════════════════════════
  if(liveScreen&&gs.isLive){
    const lp=PLAT.find(p=>p.id===gs.livePlat);
    const ss=gs.ss;
    const visChat=gs.liveChat.filter(m=>!m.banned);
    const volWarn=(ss.vol||80)>90||(ss.game||70)>90||(ss.music||40)>82;
    const micWarn=(ss.mic||75)>86;
    return(
      <div style={{height:"100vh",background:"#060608",display:"flex",flexDirection:"column",fontFamily:"'Courier New',monospace",color:"#e0e0e0",overflow:"hidden"}}>
        {/* TOP BAR */}
        <div style={{background:"#0f0f16",borderBottom:"1px solid #1a1a2e",padding:"5px 12px",display:"flex",alignItems:"center",gap:8,flexShrink:0,flexWrap:"wrap"}}>
          <span style={{width:8,height:8,background:"#ff4444",borderRadius:"50%",display:"inline-block",animation:"blink 1s infinite",flexShrink:0}}></span>
          <span style={{color:"#ff4444",fontWeight:700,fontSize:12}}>CANLI</span>
          <span style={{color:lp.color,fontSize:12}}>{lp.icon} {lp.name}</span>
          <span style={{fontSize:10,color:"#666"}}>⏱ {fmtT(gs.liveSecs)}</span>
          <span style={{fontSize:11}}>👁 <b>{fmt(gs.liveV)}</b></span>
          <span style={{fontSize:11,color:"#4ade80"}}>💰 {fmtM(gs.money)}</span>
          <span style={{fontSize:11,color:lp.color}}>⭐ {fmt(gs.kickSubs)}</span>
          <span style={{fontSize:9,background:"#1a1a2e",border:"1px solid #2a2a4e",padding:"2px 6px",borderRadius:2,color:ss.bit<3000?"#ff8800":"#4ade80"}}>{ss.res} • {ss.bit}k</span>
          {volWarn&&<span style={{fontSize:9,background:"#2d1a00",border:"1px solid #5a3a00",padding:"2px 6px",borderRadius:2,color:"#ff8800",animation:"pulse 2s infinite"}}>⚠️ Ses yüksek!</span>}
          {micWarn&&<span style={{fontSize:9,background:"#2d1a00",border:"1px solid #5a3a00",padding:"2px 6px",borderRadius:2,color:"#ff8800"}}>🎤 Mic yüksek!</span>}
          <button onClick={()=>setShowLiveSettings(s=>!s)} style={{padding:"3px 9px",background:showLiveSettings?"#0a2d0a":"#1a1a2e",border:`1px solid ${showLiveSettings?"#53FC18":"#2a2a4e"}`,color:showLiveSettings?"#53FC18":"#777",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontSize:10}}>⚙️ Ayarlar</button>
          <button onClick={()=>setActiveScene("ending")} style={{marginLeft:"auto",padding:"4px 12px",background:"#5a0000",border:"1px solid #8a0000",color:"#fff",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontSize:11,fontWeight:700}}>⏹ BİTİR</button>
        </div>

        {/* LIVE SETTINGS PANEL */}
        {showLiveSettings&&(
          <div style={{background:"#0d0d14",borderBottom:"2px solid #1a1a2e",padding:"9px 12px",display:"flex",gap:14,flexWrap:"wrap",flexShrink:0}}>
            {/* Volume */}
            <div style={{minWidth:180}}>
              <div style={{fontSize:9,color:"#444",marginBottom:5,letterSpacing:1}}>🔊 SES</div>
              {[{l:"Ana",k:"vol",c:"#4ade80"},{l:"Oyun",k:"game",c:"#ffd700"},{l:"Müzik",k:"music",c:"#c77dff"},{l:"Mikrofon",k:"mic",c:"#4d96ff"}].map(({l,k,c})=>(
                <div key={k} style={{display:"flex",alignItems:"center",gap:7,marginBottom:4}}>
                  <span style={{fontSize:9,color:"#555",width:52,flexShrink:0}}>{l}</span>
                  <input type="range" min={0} max={100} value={ss[k]||0} onChange={e=>setGs(g=>({...g,ss:{...g.ss,[k]:+e.target.value}}))} style={{flex:1,accentColor:c}} />
                  <span style={{fontSize:9,color:(ss[k]||0)>85?"#ff8800":c,width:28,textAlign:"right"}}>{ss[k]||0}%</span>
                </div>
              ))}
            </div>
            {/* Camera & Mic */}
            <div style={{minWidth:150}}>
              <div style={{fontSize:9,color:"#444",marginBottom:5,letterSpacing:1}}>📷 CİHAZLAR</div>
              <select value={ss.camera} onChange={e=>setGs(g=>({...g,ss:{...g.ss,camera:e.target.value}}))} style={{...SEL,marginBottom:5,fontSize:9}}>
                {["Kamera Yok","Kamera 1 (720p)","Kamera 1 (1080p)","Telefon Kamerası","Harici 4K"].map(c=><option key={c} value={c}>{c}</option>)}
              </select>
              <select value={ss.micDev} onChange={e=>setGs(g=>({...g,ss:{...g.ss,micDev:e.target.value}}))} style={{...SEL,fontSize:9}}>
                {["Varsayılan Mikrofon","Headset Mikrofonu","USB Kondenser","Mikrofon Kapalı"].map(m=><option key={m} value={m}>{m}</option>)}
              </select>
            </div>
            {/* Resolution */}
            <div style={{minWidth:140}}>
              <div style={{fontSize:9,color:"#444",marginBottom:5,letterSpacing:1}}>🎦 KALİTE</div>
              <select value={ss.res} onChange={e=>setGs(g=>({...g,ss:{...g.ss,res:e.target.value}}))} style={{...SEL,marginBottom:5,fontSize:9}}>
                {["144p","360p","480p","720p60","1080p60","1440p60","4K60"].map(r=><option key={r} value={r}>{r}</option>)}
              </select>
              <select value={ss.bit} onChange={e=>setGs(g=>({...g,ss:{...g.ss,bit:+e.target.value}}))} style={{...SEL,fontSize:9}}>
                {[1000,2500,4000,6000,8000,12000,18000].map(b=><option key={b} value={b}>{b}kbps</option>)}
              </select>
            </div>
            {/* Game events */}
            <div style={{minWidth:180}}>
              <div style={{fontSize:9,color:"#444",marginBottom:5,letterSpacing:1}}>🎮 OYUN OLAYI</div>
              <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
                {[["💀 Öldü","died"],["🏆 Drop","drop"],["⚔️ Clutch","clutch"],["😂 Komik","funny"],["😡 Rage","rage"]].map(([lb,ev])=>(
                  <button key={ev} onClick={()=>triggerGameEvent(ev)} style={{padding:"4px 8px",background:"#1a1a2e",border:"1px solid #2a2a4e",borderRadius:2,color:"#ccc",cursor:"pointer",fontFamily:"inherit",fontSize:9}}>{lb}</button>
                ))}
              </div>
              <div style={{marginTop:7,fontSize:9,color:"#444"}}>🌐 {isp.name} • {isp.upload}Mbps upload</div>
            </div>
          </div>
        )}

        <div style={{flex:1,display:"flex",overflow:"hidden",userSelect:isDrag?"none":"auto"}}>
          {/* STREAM VIEWPORT */}
          <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",position:"relative"}}>

            {/* MAIN STREAM CANVAS */}
            <div style={{flex:1,position:"relative",overflow:"hidden",background:
              activeScene==="game"?"linear-gradient(135deg,#0a0f1a,#0d1520,#0a0f1a)":
              activeScene==="chat"?"linear-gradient(135deg,#0a0a1a,#12121e,#0a0a1a)":
              activeScene==="brb"?"linear-gradient(135deg,#080808,#101010,#080808)":
              activeScene==="mic"?"linear-gradient(135deg,#0f0a1a,#1a1228,#0f0a1a)":
              "linear-gradient(135deg,#0a0000,#1a0505,#0a0000)"
            }}>

              {/* ── GAME SCENE ── */}
              {activeScene==="game"&&(
                <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                  {/* Fake game grid background */}
                  <div style={{position:"absolute",inset:0,backgroundImage:"linear-gradient(rgba(83,252,24,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(83,252,24,0.03) 1px,transparent 1px)",backgroundSize:"40px 40px",pointerEvents:"none"}} />
                  <div style={{textAlign:"center",zIndex:1,padding:20}}>
                    <div style={{fontSize:gameEvIcon?80:64,marginBottom:12,transition:"all 0.4s",filter:gameEvIcon?"drop-shadow(0 0 40px #ff4444)":"drop-shadow(0 0 20px rgba(83,252,24,0.2))"}}>{gameEvIcon||"🎮"}</div>
                    <div style={{fontSize:22,fontWeight:900,color:"#fff",letterSpacing:1}}>{gs.channelName}</div>
                    <div style={{fontSize:11,color:"#444",marginTop:4}}>{ss.src}</div>
                    {/* Vol meters */}
                    <div style={{display:"flex",gap:6,justifyContent:"center",marginTop:16,alignItems:"flex-end"}}>
                      {[{k:"vol",c:"#4ade80",l:"🔊"},{k:"game",c:"#ffd700",l:"🎮"},{k:"music",c:"#c77dff",l:"🎵"},{k:"mic",c:"#4d96ff",l:"🎤"}].map(({k,c,l})=>{
                        const v=ss[k]||0,warn=v>85;
                        return(<div key={k} style={{textAlign:"center"}}>
                          <div style={{width:8,height:44,background:"rgba(0,0,0,0.5)",borderRadius:3,overflow:"hidden",display:"flex",flexDirection:"column",justifyContent:"flex-end",border:"1px solid #1a1a2e"}}>
                            <div style={{width:"100%",height:v+"%",background:warn?"#ff6b00":c,borderRadius:2,transition:"height 0.4s"}} />
                          </div>
                          <div style={{fontSize:8,color:warn?"#ff8800":"#333",marginTop:2}}>{l}</div>
                        </div>);
                      })}
                    </div>
                  </div>
                  {/* Camera facecam */}
                  {ss.camera!=="Kamera Yok"&&<div style={{position:"absolute",bottom:52,left:12,width:100,height:72,background:"#0d1117",border:"2px solid "+lp.color+"55",borderRadius:6,display:"flex",alignItems:"center",justifyContent:"center",fontSize:30,overflow:"hidden",boxShadow:"0 4px 20px rgba(0,0,0,0.5)"}}>😊</div>}
                </div>
              )}

              {/* ── JUST CHATTING SCENE ── */}
              {activeScene==="chat"&&(
                <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                  <div style={{position:"absolute",inset:0,background:"radial-gradient(circle at 50% 50%, rgba(83,252,24,0.04) 0%, transparent 70%)",pointerEvents:"none"}} />
                  <div style={{textAlign:"center",zIndex:1}}>
                    <div style={{fontSize:56,marginBottom:16}}>💬</div>
                    <div style={{fontSize:24,fontWeight:900,color:"#fff"}}>{gs.channelName}</div>
                    <div style={{fontSize:12,color:"#555",marginTop:6}}>Just Chatting</div>
                    <div style={{marginTop:20,display:"flex",gap:12,justifyContent:"center"}}>
                      <div style={{background:"rgba(83,252,24,0.08)",border:"1px solid rgba(83,252,24,0.2)",borderRadius:8,padding:"10px 18px",textAlign:"center"}}>
                        <div style={{fontSize:18,fontWeight:700,color:"#53FC18"}}>{fmt(gs.liveV)}</div>
                        <div style={{fontSize:9,color:"#555",marginTop:2}}>izleyici</div>
                      </div>
                      <div style={{background:"rgba(255,215,0,0.08)",border:"1px solid rgba(255,215,0,0.2)",borderRadius:8,padding:"10px 18px",textAlign:"center"}}>
                        <div style={{fontSize:18,fontWeight:700,color:"#ffd700"}}>{fmtT(gs.liveSecs)}</div>
                        <div style={{fontSize:9,color:"#555",marginTop:2}}>yayın süresi</div>
                      </div>
                      <div style={{background:"rgba(77,150,255,0.08)",border:"1px solid rgba(77,150,255,0.2)",borderRadius:8,padding:"10px 18px",textAlign:"center"}}>
                        <div style={{fontSize:18,fontWeight:700,color:"#4d96ff"}}>{fmt(gs.kickSubs)}</div>
                        <div style={{fontSize:9,color:"#555",marginTop:2}}>abone</div>
                      </div>
                    </div>
                  </div>
                  {ss.camera!=="Kamera Yok"&&<div style={{position:"absolute",bottom:52,left:12,width:100,height:72,background:"#0d1117",border:"2px solid "+lp.color+"55",borderRadius:6,display:"flex",alignItems:"center",justifyContent:"center",fontSize:30}}>😊</div>}
                </div>
              )}

              {/* ── BRB SCENE ── */}
              {activeScene==="brb"&&(
                <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                  <div style={{position:"absolute",inset:0,background:"radial-gradient(circle at 50% 40%, rgba(255,215,0,0.04) 0%, transparent 60%)",pointerEvents:"none"}} />
                  <div style={{textAlign:"center",zIndex:1}}>
                    <div style={{fontSize:64,marginBottom:14,animation:"float 3s ease-in-out infinite"}}>☕</div>
                    <div style={{fontSize:28,fontWeight:900,color:"#fff",letterSpacing:4}}>BRB</div>
                    <div style={{fontSize:13,color:"#666",marginTop:8}}>Hemen geri dönüyorum...</div>
                    <div style={{marginTop:20,fontSize:11,color:"#444"}}>Yayın devam ediyor • {fmtT(gs.liveSecs)}</div>
                    <div style={{marginTop:6,display:"flex",gap:3,justifyContent:"center"}}>
                      {[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:"50%",background:"#ffd700",animation:"blink 1.2s "+i*.4+"s infinite"}} />)}
                    </div>
                  </div>
                </div>
              )}

              {/* ── MIC / IRL SCENE ── */}
              {activeScene==="mic"&&(
                <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                  <div style={{position:"absolute",inset:0,background:"radial-gradient(circle at 50% 50%, rgba(77,150,255,0.05) 0%, transparent 70%)",pointerEvents:"none"}} />
                  <div style={{textAlign:"center",zIndex:1}}>
                    <div style={{fontSize:60,marginBottom:14}}>🎤</div>
                    <div style={{fontSize:20,fontWeight:700,color:"#fff"}}>{gs.channelName}</div>
                    <div style={{fontSize:11,color:"#555",marginTop:4}}>{ss.micDev}</div>
                    {/* Mic level animation */}
                    <div style={{marginTop:18,display:"flex",gap:3,justifyContent:"center",alignItems:"flex-end",height:40}}>
                      {Array.from({length:12},(_,i)=>{
                        const h=15+~~(Math.abs(Math.sin(i*0.8))*25);
                        return <div key={i} style={{width:4,borderRadius:2,background:"#4d96ff",opacity:0.6+(i%3)*0.1,height:h,animation:"blink "+(0.3+i*.08)+"s "+(i*.05)+"s infinite"}} />;
                      })}
                    </div>
                    <div style={{marginTop:8,fontSize:10,color:"#4d96ff"}}>🎤 {ss.micVolume||ss.mic}% • {ss.micDev.split(" ")[0]}</div>
                  </div>
                </div>
              )}

              {/* ── ENDING SCENE ── */}
              {activeScene==="ending"&&(
                <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                  <div style={{position:"absolute",inset:0,background:"radial-gradient(circle at 50% 50%, rgba(255,68,68,0.06) 0%, transparent 70%)",pointerEvents:"none"}} />
                  <div style={{textAlign:"center",zIndex:1,padding:20}}>
                    <div style={{fontSize:52,marginBottom:14}}>🏁</div>
                    <div style={{fontSize:22,fontWeight:900,color:"#fff",letterSpacing:2}}>YAYINI KAPATIYORUM</div>
                    <div style={{fontSize:12,color:"#666",marginTop:8}}>Görüşmek üzere!</div>
                    <div style={{marginTop:24,background:"rgba(255,68,68,0.08)",border:"1px solid rgba(255,68,68,0.25)",borderRadius:8,padding:"14px 24px",display:"inline-block"}}>
                      <div style={{fontSize:11,color:"#888",marginBottom:6}}>Yayın Özeti</div>
                      <div style={{display:"flex",gap:16,fontSize:12}}>
                        <div style={{textAlign:"center"}}><div style={{fontWeight:700,color:"#4ade80"}}>{fmtT(gs.liveSecs)}</div><div style={{fontSize:9,color:"#555"}}>süre</div></div>
                        <div style={{textAlign:"center"}}><div style={{fontWeight:700,color:"#4d96ff"}}>{fmt(gs.liveV)}</div><div style={{fontSize:9,color:"#555"}}>izleyici</div></div>
                        <div style={{textAlign:"center"}}><div style={{fontWeight:700,color:"#ffd700"}}>{fmtM(gs.liveDons.reduce((s,d)=>s+d.amount,0))}</div><div style={{fontSize:9,color:"#555"}}>bağış</div></div>
                        <div style={{textAlign:"center"}}><div style={{fontWeight:700,color:"#53FC18"}}>{fmt(gs.kickSubs)}</div><div style={{fontSize:9,color:"#555"}}>sub</div></div>
                      </div>
                    </div>
                    {!endConfirm?(
                      <div style={{marginTop:20,display:"flex",gap:10,justifyContent:"center"}}>
                        <button onClick={()=>setEndConfirm(true)} style={{padding:"9px 22px",background:"#5a0000",border:"1px solid #8a0000",color:"#ff8888",cursor:"pointer",borderRadius:4,fontFamily:"inherit",fontSize:12,fontWeight:700}}>⏹ Yayını Bitir</button>
                        <button onClick={()=>setActiveScene("game")} style={{padding:"9px 22px",background:"#1a1a2e",border:"1px solid #2a2a4e",color:"#888",cursor:"pointer",borderRadius:4,fontFamily:"inherit",fontSize:12}}>← Geri Dön</button>
                      </div>
                    ):(
                      <div style={{marginTop:20}}>
                        <div style={{fontSize:11,color:"#ff8888",marginBottom:10}}>Emin misin? Chat'e veda mesajı gönderilecek.</div>
                        <div style={{display:"flex",gap:10,justifyContent:"center"}}>
                          <button onClick={requestEndLive} style={{padding:"9px 22px",background:"#ff4444",border:"none",color:"#fff",cursor:"pointer",borderRadius:4,fontFamily:"inherit",fontSize:12,fontWeight:700}}>✅ Evet, Bitir</button>
                          <button onClick={()=>setEndConfirm(false)} style={{padding:"9px 22px",background:"#1a1a2e",border:"1px solid #2a2a4e",color:"#888",cursor:"pointer",borderRadius:4,fontFamily:"inherit",fontSize:12}}>İptal</button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ── HUD OVERLAYS (all scenes) ── */}
              <div style={{position:"absolute",top:10,left:10,background:"rgba(0,0,0,0.8)",borderRadius:4,padding:"3px 8px",fontSize:11,display:"flex",alignItems:"center",gap:5,zIndex:5}}>
                <span style={{color:"#ff4444",animation:"blink 1s infinite",fontSize:9}}>●</span>{fmt(gs.liveV)} izleyici
              </div>
              <div style={{position:"absolute",top:10,right:10,background:"rgba(0,0,0,0.8)",borderRadius:4,padding:"3px 9px",fontSize:10,zIndex:5}}>{fmtT(gs.liveSecs)}</div>
              <div style={{position:"absolute",top:10,left:"50%",transform:"translateX(-50%)",background:"rgba(0,0,0,0.8)",borderRadius:4,padding:"2px 8px",fontSize:9,color:lp.color,fontWeight:700,zIndex:5,whiteSpace:"nowrap"}}>{lp.name.toUpperCase()} • {ss.res}</div>
              {/* Mic/vol status bottom */}
              <div style={{position:"absolute",bottom:10,left:ss.camera!=="Kamera Yok"&&activeScene==="game"?118:10,display:"flex",gap:5,zIndex:5}}>
                <span style={{fontSize:8,color:micWarn?"#ff8800":"#4ade80",background:"rgba(0,0,0,0.75)",padding:"2px 6px",borderRadius:2}}>🎤 {ss.mic||75}%{micWarn?" ⚠️":""}</span>
                <span style={{fontSize:8,color:volWarn?"#ff8800":"#666",background:"rgba(0,0,0,0.75)",padding:"2px 6px",borderRadius:2}}>🔊 {ss.vol||80}%{volWarn?" ⚠️":""}</span>
              </div>
              {/* AI popup */}
              {aiPop&&<div style={{position:"absolute",top:52,right:10,background:"rgba(6,6,18,0.96)",border:"1px solid "+lp.color+"88",borderRadius:6,padding:"8px 11px",maxWidth:195,fontSize:10,color:"#ccc",animation:"fadeIn 0.3s ease",zIndex:20,whiteSpace:"pre-line"}}><div style={{fontSize:8,color:lp.color,marginBottom:3}}>🤖 Chat tepkisi</div>{aiPop}</div>}
              {/* Donation */}
              {donPop&&<div style={{position:"absolute",bottom:22,left:"50%",transform:"translateX(-50%)",background:"linear-gradient(135deg,#1a1200,#2a2000)",border:"2px solid #ffd700",borderRadius:8,padding:"13px 24px",textAlign:"center",minWidth:265,boxShadow:"0 0 36px rgba(255,215,0,0.28)",animation:"popIn 0.3s ease",zIndex:15}}><div style={{fontSize:22,marginBottom:3}}>💰</div><div style={{color:"#ffd700",fontWeight:700,fontSize:14}}>{donPop.user}</div><div style={{color:"#4ade80",fontSize:20,fontWeight:700}}>+{fmtM(donPop.amount)}</div><div style={{color:"#ccc",fontSize:11,marginTop:4}}>{donPop.msg}</div></div>}
              {/* Sub */}
              {subPop&&<div style={{position:"absolute",top:52,left:"50%",transform:"translateX(-50%)",background:"linear-gradient(135deg,#001500,#002800)",border:"2px solid #53FC18",borderRadius:8,padding:"10px 22px",textAlign:"center",minWidth:210,boxShadow:"0 0 26px rgba(83,252,24,0.28)",animation:"popIn 0.3s ease",zIndex:15}}><div style={{fontSize:18}}>⭐</div><div style={{color:"#53FC18",fontWeight:700,fontSize:14}}>{subPop.user}</div><div style={{color:"#aaa",fontSize:10,marginTop:2}}>Tier {subPop.tier} Abone!</div></div>}
              {/* Game event banner */}
              {gameEvBanner&&<div style={{position:"absolute",top:"32%",left:"50%",transform:"translateX(-50%)",background:"rgba(0,0,0,0.93)",border:"2px solid "+gameEvBanner.color,borderRadius:8,padding:"12px 28px",textAlign:"center",animation:"popIn 0.2s ease",zIndex:20}}><div style={{fontSize:36}}>{gameEvBanner.icon}</div><div style={{color:gameEvBanner.color,fontWeight:900,fontSize:20,letterSpacing:3}}>{gameEvBanner.title}</div><div style={{color:"#777",fontSize:11,marginTop:2}}>{gameEvBanner.sub}</div></div>}
            </div>

            {/* ── SCENE BAR ── */}
            <div style={{background:"#0a0a12",borderTop:"1px solid #1a1a2e",padding:"6px 10px",display:"flex",gap:6,flexShrink:0,alignItems:"center"}}>
              <span style={{fontSize:9,color:"#2a2a3e",marginRight:2,flexShrink:0}}>SAHNE:</span>
              {[
                {id:"game",  icon:"🎮", label:"Oyun"},
                {id:"chat",  icon:"💬", label:"Sohbet"},
                {id:"mic",   icon:"🎤", label:"IRL/Mic"},
                {id:"brb",   icon:"☕", label:"BRB"},
                {id:"ending",icon:"🏁", label:"Bitiş"},
              ].map(sc=>(
                <button key={sc.id} onClick={()=>setActiveScene(sc.id)} style={{
                  padding:"4px 10px",
                  background:activeScene===sc.id?(sc.id==="ending"?"#2d0000":"#0a1a0a"):"#111118",
                  border:"1px solid "+(activeScene===sc.id?(sc.id==="ending"?"#ff4444":lp.color):"#1a1a2e"),
                  borderRadius:4,
                  color:activeScene===sc.id?(sc.id==="ending"?"#ff8888":lp.color):"#555",
                  cursor:"pointer",fontFamily:"inherit",fontSize:10,
                  display:"flex",alignItems:"center",gap:4,
                  fontWeight:activeScene===sc.id?700:400,
                  transition:"all 0.15s",
                }}>{sc.icon} {sc.label}</button>
              ))}
              <div style={{marginLeft:"auto",display:"flex",gap:5,alignItems:"center"}}>
                {[{k:"vol",c:"#4ade80",l:"🔊"},{k:"game",c:"#ffd700",l:"🎮"},{k:"music",c:"#c77dff",l:"🎵"}].map(({k,c,l})=>{
                  const v=ss[k]||0;
                  return(<div key={k} style={{display:"flex",alignItems:"center",gap:2}}>
                    <span style={{fontSize:8,color:"#333"}}>{l}</span>
                    <div style={{width:30,height:3,background:"#1a1a2e",borderRadius:2,overflow:"hidden"}}>
                      <div style={{height:"100%",width:v+"%",background:v>85?"#ff6b00":c,borderRadius:2}} />
                    </div>
                  </div>);
                })}
              </div>
            </div>
          </div>

          {/* DRAG HANDLE - hide when collapsed */}
          {!chatCollapsed && <div onMouseDown={onDragStart} style={{width:5,background:isDrag?"#53FC18":"#1a1a2e",cursor:"col-resize",flexShrink:0,transition:"background 0.2s"}} />}

          {/* CHAT PANEL */}
          <div style={{width:chatCollapsed?32:chatW,display:"flex",flexDirection:"column",background:"#09090f",flexShrink:0,transition:"width 0.25s ease",overflow:"hidden"}}>
            {/* HEADER */}
            <div style={{padding:"5px 6px",borderBottom:"1px solid #1a1a2e",background:"#0f0f16",display:"flex",justifyContent:"space-between",alignItems:"center",flexShrink:0,minWidth:0}}>
              {!chatCollapsed && (
                <span style={{color:lp.color,fontWeight:700,fontSize:11,whiteSpace:"nowrap"}}>SOHBET <span style={{color:"#2a2a3e",fontSize:9,fontWeight:400}}>{visChat.length}</span></span>
              )}
              <div style={{display:"flex",gap:3,marginLeft:chatCollapsed?"0":"auto",flexShrink:0}}>
                {/* Collapse / Expand toggle */}
                <button
                  onClick={()=>{
                    if(chatCollapsed){setChatW(prevChatW.current);setChatCollapsed(false);}
                    else{prevChatW.current=chatW;setChatCollapsed(true);}
                  }}
                  title={chatCollapsed?"Chati Aç":"Chati Kapat"}
                  style={{padding:"2px 6px",background:chatCollapsed?"#1a2a1a":"#1a1a2e",border:`1px solid ${chatCollapsed?"#53FC18":"#2a2a4e"}`,borderRadius:2,color:chatCollapsed?"#53FC18":"#888",cursor:"pointer",fontFamily:"inherit",fontSize:10,lineHeight:1}}
                >{chatCollapsed?"▶":"✕"}</button>
                {/* Size buttons - only when expanded */}
                {!chatCollapsed && (<>
                  <button onClick={()=>setChatW(200)} style={BS2}>S</button>
                  <button onClick={()=>setChatW(300)} style={BS2}>M</button>
                  <button onClick={()=>setChatW(480)} style={BS2}>L</button>
                </>)}
              </div>
            </div>
            {/* Rest of chat - hidden when collapsed */}
            {!chatCollapsed && (<>
              {gs.liveDons.length>0&&(
                <div style={{background:"#090800",borderBottom:"1px solid #2a2000",padding:"4px 7px",flexShrink:0}}>
                  <div style={{fontSize:8,color:"#ffd700",marginBottom:2}}>💰 BAĞIŞLAR</div>
                  {gs.liveDons.slice(0,3).map(d=><div key={d.id} style={{fontSize:9,display:"flex",justifyContent:"space-between",color:"#666",marginBottom:1}}><span>{d.user}</span><span style={{color:"#4ade80"}}>+{fmtM(d.amount)}</span></div>)}
                </div>
              )}
              <div ref={chatRef} style={{flex:1,overflowY:"auto",padding:"4px 3px",display:"flex",flexDirection:"column",gap:1}}>
                {visChat.map(m=>(
                  <div key={m.id} style={{padding:"3px 5px",borderRadius:2,background:m.isDon?"rgba(255,215,0,0.07)":m.isSubAlert?"rgba(83,252,24,0.05)":m.isMod?"rgba(83,252,24,0.04)":m.isAiReply?"rgba(100,80,255,0.07)":"transparent",borderLeft:m.isDon?"2px solid #ffd700":m.isSubAlert?"2px solid #53FC18":m.isMod?"2px solid #4ade80":m.isAiReply?"2px solid #8888ff":"none",opacity:m.timedOut?.2:1}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                      <span style={{fontSize:10,fontWeight:700,color:m.color,maxWidth:chatW-55,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{m.isSub&&!m.isDon&&!m.isSubAlert?"⭐":""}{m.isAiReply?"🤖":""} {m.user}</span>
                      {!m.isMod&&!m.isSubAlert&&!m.isDon&&!m.isAiReply&&(
                        <div style={{display:"flex",gap:1,flexShrink:0}}>
                          <button onClick={()=>toutUser(m.user)} style={{padding:"1px 4px",background:"none",border:"none",color:"#3a3a00",cursor:"pointer",fontSize:9}}>⏱</button>
                          <button onClick={()=>banUser(m.user)} style={{padding:"1px 4px",background:"none",border:"none",color:"#3a0000",cursor:"pointer",fontSize:9}}>🔨</button>
                        </div>
                      )}
                    </div>
                    <div style={{fontSize:chatW<240?9:10,color:m.timedOut?"#222":m.isDon?"#ffd700":m.isAiReply?"#9999ff":"#ccc",marginTop:1,wordBreak:"break-word"}}>{m.timedOut?"[timeout]":m.text}</div>
                  </div>
                ))}
              </div>
              <div style={{padding:"5px",borderTop:"1px solid #1a1a2e",display:"flex",gap:3,flexShrink:0}}>
                <input value={chatIn} onChange={e=>setChatIn(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendChat()} placeholder="Sohbete yaz..." style={{flex:1,background:"#1a1a2e",border:"1px solid #2a2a4e",borderRadius:2,padding:"5px 7px",color:"#fff",fontSize:10,fontFamily:"inherit",outline:"none"}} />
                <button onClick={sendChat} style={{padding:"5px 8px",background:lp.color,border:"none",color:"#000",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontSize:10,fontWeight:700}}>▶</button>
              </div>
            </>)}
          </div>
        </div>
        <style>{`@keyframes blink{0%,100%{opacity:1}50%{opacity:0.15}}@keyframes popIn{from{transform:translateX(-50%) scale(0.82);opacity:0}to{transform:translateX(-50%) scale(1);opacity:1}}@keyframes fadeIn{from{opacity:0;transform:translateY(-5px)}to{opacity:1;transform:translateY(0)}}@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.5}}@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}*{box-sizing:border-box}::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#1a1a2e}`}</style>
      </div>
    );
  }

  // ══ MAIN GAME UI ═════════════════════════════════════════════════════════════
  return(
    <div style={{minHeight:"100vh",background:"#0a0a0f",fontFamily:"'Courier New',monospace",color:"#e0e0e0"}}>
      {/* Topbar */}
      <div style={{background:"#111118",borderBottom:"1px solid #1a1a2e",padding:"7px 14px",display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
        <span style={{color:plat.color,fontSize:15}}>{plat.icon}</span>
        <span style={{fontWeight:700,fontSize:13}}>{gs.channelName}</span>
        {gs.tickStatus&&<span style={{background:"#777",borderRadius:"50%",width:16,height:16,display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:700}}>✓</span>}
        {gs.strikes>0&&<span style={{background:"#5a0000",padding:"1px 7px",borderRadius:2,fontSize:9}}>⚠️ {gs.strikes}/3</span>}
        <button onClick={()=>setDiscOpen(d=>!d)} style={{marginLeft:8,padding:"3px 9px",background:discOpen?"#5865F2":"#1a1a2e",border:`1px solid ${discOpen?"#5865F2":"#2a2a4e"}`,borderRadius:2,color:"#fff",cursor:"pointer",fontFamily:"inherit",fontSize:10,display:"flex",alignItems:"center",gap:4}}>
          <span>💬</span> Discord
        </button>
        <div style={{marginLeft:"auto",display:"flex",gap:12,fontSize:11}}>
          <span>👥 {fmt(gs.subscribers)}</span>
          <span style={{color:"#53FC18"}}>⭐ {fmt(gs.kickSubs)}</span>
          <span>👁 {fmt(gs.totalViews)}</span>
          <span style={{color:"#4ade80"}}>💰 {fmtM(gs.money)}</span>
          <span style={{color:"#444"}}>📅 {gs.day}. Gün</span>
        </div>
      </div>

      {/* Notifs */}
      {gs.notifs.length>0&&<div style={{background:"#0d0d14",borderBottom:"1px solid #1a1a2e",padding:"4px 14px",display:"flex",gap:5,overflowX:"auto"}}>{gs.notifs.slice(0,4).map(n=><span key={n.id} style={{fontSize:9,padding:"3px 8px",borderRadius:2,whiteSpace:"nowrap",background:n.type==="error"?"#2d0a0a":n.type==="special"?"#1a1a00":n.type==="success"?"#0a2d0a":"#1a1a2e",border:`1px solid ${n.type==="error"?"#5a1a1a":n.type==="special"?"#5a5a00":n.type==="success"?"#1a5a1a":"#2a2a4e"}`}}>{n.msg}</span>)}</div>}

      {/* Nav */}
      <div style={{background:"#111118",borderBottom:"1px solid #1a1a2e",padding:"0 14px",display:"flex"}}>
        {[["🏠","main"],["🎬","studio"],["✂️","edit"],["📊","analytics"],["💼","sponsors"],["⚙️","settings"]].map(([icon,id])=>(
          <button key={id} onClick={()=>setGs(g=>({...g,tab:id}))} style={{padding:"8px 10px",background:"transparent",border:"none",borderBottom:gs.tab===id?`2px solid ${plat.color}`:"2px solid transparent",color:gs.tab===id?"#fff":"#444",cursor:"pointer",fontSize:13,fontFamily:"inherit"}}>{icon}</button>
        ))}
      </div>

      <div style={{display:"flex"}}>
        <div style={{flex:1,padding:14,maxWidth:960,margin:"0 auto"}}>

          {/* MAIN */}
          {gs.tab==="main"&&(<div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(120px,1fr))",gap:7,marginBottom:14}}>
              {[{l:"Aboneler",v:fmt(gs.subscribers),i:"👥",hi:gs.tickStatus},{l:"Kick Sub",v:fmt(gs.kickSubs),i:"⭐",c:"#53FC18"},{l:"İzlenme",v:fmt(gs.totalViews),i:"👁"},{l:"Bakiye",v:fmtM(gs.money),i:"💰",c:"#4ade80"},{l:"Videolar",v:gs.videos.length,i:"🎬"},{l:"İnternet",v:isp.sq,i:"🌐"}].map((s,i)=>(
                <div key={i} style={{background:"#111118",border:`1px solid ${s.hi?"#666":"#1a1a2e"}`,borderRadius:2,padding:"10px 12px"}}><div style={{fontSize:16,marginBottom:3}}>{s.i}</div><div style={{fontSize:15,fontWeight:700,color:s.c||(s.hi?"#ccc":"#fff")}}>{s.v}</div><div style={{fontSize:9,color:"#444",marginTop:1}}>{s.l}</div></div>
              ))}
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(110px,1fr))",gap:6,marginBottom:14}}>
              <GB l="🎥 Video Çek" disabled={gs.isRecording||!!gs.rawVid||!!gs.editedVid} color="#e53e3e" onClick={()=>setRecModal(true)} />
              <GB l="✂️ Düzenle"  disabled={!gs.rawVid} color="#9146FF" onClick={openEdit} />
              <GB l="📤 Yükle"   disabled={!gs.editedVid||gs.isUploading} color={plat.color} onClick={()=>{setUpTitle("");setUpDesc("");setUpModal(true);}} />
              <GB l="📡 Canlı"   color="#ff6b35" onClick={openStreamSetup} />
              <GB l="✏️ İsim"    color="#444" onClick={()=>{setNewName(gs.channelName);setRenameModal(true);}} />
              <GB l="📅 +1 Gün"  color="#2563eb" onClick={nextDay} />
            </div>
            {gs.isRecording&&<PB label={`🎥 Çekiliyor (${CATS.find(c=>c.id===gs.recCat)?.name})`} val={gs.recProg} color="#e53e3e" />}
            {gs.isUploading&&<PB label={`📤 Yükleniyor (${isp.name})`} val={gs.upProg} color={plat.color} />}
            {gs.rawVid&&!gs.isRecording&&<div style={{background:"#1a1a00",border:"1px solid #3a3a00",borderRadius:2,padding:"8px 12px",marginBottom:8,fontSize:11}}>📼 Ham video: <b>{CATS.find(c=>c.id===gs.rawVid.cat)?.emoji} {CATS.find(c=>c.id===gs.rawVid.cat)?.name}</b> — {gs.rawVid.mins} dk <span style={{color:"#9146FF",cursor:"pointer"}} onClick={openEdit}>Düzenle →</span></div>}
            {gs.editedVid&&!gs.isUploading&&<div style={{background:"#0a2d0a",border:"1px solid #1a5a1a",borderRadius:2,padding:"8px 12px",marginBottom:8,fontSize:11}}>✅ Kalite: <b>{gs.editedVid.quality}</b> <span style={{color:plat.color,cursor:"pointer"}} onClick={()=>{setUpTitle("");setUpDesc("");setUpModal(true);}}>Yükle →</span></div>}
            {gs.videos.length>0&&(<div>
              <div style={{fontSize:9,letterSpacing:1,color:"#333",marginBottom:7}}>SON VİDEOLAR</div>
              {gs.videos.slice(0,6).map(v=>{const cat=CATS.find(c=>c.id===v.cat);return(<div key={v.id} onClick={()=>gs.ytComments[v.id]&&setCmtModal(v)} style={{background:"#111118",border:"1px solid #1a1a2e",borderRadius:2,padding:"8px 12px",display:"flex",alignItems:"center",gap:9,marginBottom:4,fontSize:11,cursor:gs.ytComments[v.id]?"pointer":"default"}}><span style={{fontSize:16}}>{cat?.emoji}</span><span style={{flex:1,fontWeight:600}}>{v.title}</span><span style={{color:"#888"}}>👁 {fmt(v.views)}</span><span style={{color:"#e53e3e"}}>❤️ {fmt(v.likes)}</span><span style={{color:"#4ade80"}}>💰 {fmtM(v.earnings)}</span>{gs.ytComments[v.id]&&<span style={{color:"#555",fontSize:9}}>💬 {gs.ytComments[v.id].length}</span>}</div>);})}
            </div>)}
          </div>)}

          {/* STUDIO */}
          {gs.tab==="studio"&&(<div>
            <ST>KAYIT STÜDYOSİ</ST>
            <div style={{background:"#111118",border:"1px solid #1a1a2e",borderRadius:2,padding:18}}>
              <label style={L}>KATEGORİ</label>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6,marginBottom:14}}>
                {CATS.map(c=><button key={c.id} onClick={()=>setRecCat(c.id)} style={{padding:"9px 4px",background:recCat===c.id?"#1a1a3a":"#0d0d14",border:`1px solid ${recCat===c.id?"#5555cc":"#1a1a2e"}`,borderRadius:2,color:"#fff",cursor:"pointer",fontFamily:"inherit",fontSize:10}}>{c.emoji} {c.name}<br/><span style={{color:"#444",fontSize:9}}>~{c.base}</span></button>)}
              </div>
              <label style={L}>SÜRE: {recMins} DK</label>
              <input type="range" min={2} max={60} value={recMins} onChange={e=>setRecMins(+e.target.value)} style={{width:"100%",accentColor:"#e53e3e",marginBottom:14}} />
              <button onClick={startRec} disabled={gs.isRecording||!!gs.rawVid||!!gs.editedVid} style={{width:"100%",padding:11,background:gs.isRecording?"#333":"#e53e3e",border:"none",color:"#fff",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontWeight:700}}>
                {gs.isRecording?`🎥 ${Math.floor(gs.recProg)}%`:"🎥 ÇEKMEYE BAŞLA"}
              </button>
              {gs.isRecording&&<PB label="" val={gs.recProg} color="#e53e3e" />}
            </div>
          </div>)}

          {/* EDIT */}
          {gs.tab==="edit"&&(<div>
            <ST>EDİTÖR</ST>
            {!gs.rawVid&&!gs.editedVid?<div style={{background:"#111118",border:"1px solid #1a1a2e",borderRadius:2,padding:32,textAlign:"center",color:"#444"}}>Ham video yok. Önce video çek!</div>
            :gs.editedVid?<div style={{background:"#0a2d0a",border:"1px solid #1a5a1a",borderRadius:2,padding:"9px 12px",fontSize:11}}>✅ Kalite: <b>{gs.editedVid.quality}</b> — <span style={{color:plat.color,cursor:"pointer"}} onClick={()=>{setUpTitle("");setUpDesc("");setUpModal(true);}}>Yükle →</span></div>
            :<EditWS rawVid={gs.rawVid} done={editDone} active={editActive} tl={editTL} onStep={doStep} onFinal={finalEdit} />}
          </div>)}

          {/* ANALYTICS */}
          {gs.tab==="analytics"&&(<div>
            <ST>ANALİTİK</ST>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))",gap:7,marginBottom:14}}>
              {[{l:"Toplam Kazanç",v:fmtM(gs.videos.reduce((s,v)=>s+v.earnings,0)),i:"💰"},{l:"Ort. İzlenme",v:gs.videos.length?fmt(gs.videos.reduce((s,v)=>s+v.views,0)/gs.videos.length):"0",i:"📊"},{l:"Kick Sub",v:fmt(gs.kickSubs),i:"⭐"},{l:"Strike",v:`${gs.strikes}/3`,i:"⚖️"}].map((s,i)=>(
                <div key={i} style={{background:"#111118",border:"1px solid #1a1a2e",borderRadius:2,padding:"12px 14px"}}><div style={{fontSize:20,marginBottom:4}}>{s.i}</div><div style={{fontSize:18,fontWeight:700}}>{s.v}</div><div style={{fontSize:9,color:"#444",marginTop:2}}>{s.l}</div></div>
              ))}
            </div>
            {gs.videos.map(v=>{const cat=CATS.find(c=>c.id===v.cat),mx=Math.max(...gs.videos.map(x=>x.views),1);return(<div key={v.id} style={{background:"#111118",border:"1px solid #1a1a2e",borderRadius:2,padding:"8px 12px",marginBottom:5}}><div style={{display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:4}}><span>{cat?.emoji} <b>{v.title}</b></span><span style={{color:"#4ade80"}}>{fmtM(v.earnings)}</span></div><div style={{height:4,background:"#1a1a2e",borderRadius:2,overflow:"hidden"}}><div style={{height:"100%",width:`${(v.views/mx)*100}%`,background:plat.color}} /></div><div style={{color:"#444",fontSize:9,marginTop:3}}>{fmt(v.views)} izlenme • Kalite {v.quality} • Gün {v.day}</div></div>);})}
          </div>)}

          {/* SPONSORS */}
          {gs.tab==="sponsors"&&(<div>
            <ST>SPONSORLUKLAR</ST>
            {gs.activeSponsors.length>0&&<div style={{marginBottom:12}}><div style={{fontSize:9,color:"#444",marginBottom:5}}>AKTİF</div>{gs.activeSponsors.map(sp=><div key={sp.id} style={{background:"#0a2d0a",border:"1px solid #1a5a1a",borderRadius:2,padding:"8px 12px",display:"flex",gap:10,alignItems:"center",marginBottom:4,fontSize:11}}><span style={{fontSize:18}}>{sp.icon}</span><span style={{flex:1}}>{sp.name}</span><span style={{color:"#4ade80"}}>{fmtM(sp.pay)}</span><span style={{fontSize:9,color:"#4ade80"}}>✅</span></div>)}</div>}
            <div style={{fontSize:9,color:"#444",marginBottom:5}}>TEKLİFLER</div>
            {gs.sponsorOffers.length===0?<div style={{color:"#333",fontSize:11,padding:20,textAlign:"center"}}>Daha fazla video yükle, teklifler gelsin!</div>:gs.sponsorOffers.map(sp=>(
              <div key={sp.id} style={{background:"#111118",border:"1px solid #2a2a1a",borderRadius:2,padding:12,marginBottom:8}}>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}><span style={{fontSize:22}}>{sp.icon}</span><div><div style={{fontWeight:700,fontSize:13}}>{sp.name}</div><div style={{fontSize:9,color:"#666"}}>Min. {fmt(sp.min)} abone</div></div><span style={{marginLeft:"auto",color:"#4ade80",fontWeight:700,fontSize:15}}>{fmtM(sp.pay)}</span></div>
                <div style={{display:"flex",gap:6}}>
                  <button onClick={()=>accSponsor(sp)} style={{flex:1,padding:"7px",background:"#0a2d0a",border:"1px solid #1a5a1a",color:"#4ade80",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontSize:11,fontWeight:700}}>✅ KABUL ET</button>
                  <button onClick={()=>setGs(g=>({...g,sponsorOffers:g.sponsorOffers.filter(s=>s.id!==sp.id)}))} style={{padding:"7px 12px",background:"#2d0a0a",border:"1px solid #5a1a1a",color:"#ff4444",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontSize:11}}>✕</button>
                </div>
              </div>
            ))}
          </div>)}

          {/* SETTINGS */}
          {gs.tab==="settings"&&(<div>
            <ST>AYARLAR</ST>
            <SC3 title="🎯 Platform"><div style={{display:"flex",gap:8}}>{PLAT.map(p=><button key={p.id} onClick={()=>{setGs(g=>({...g,platform:p.id}));push(`Platform: ${p.name}`,"info");}} style={{flex:1,padding:12,background:gs.platform===p.id?"#1a1a2e":"#0d0d14",border:`2px solid ${gs.platform===p.id?p.color:"#1a1a2e"}`,borderRadius:2,color:"#fff",cursor:"pointer",fontFamily:"inherit"}}><div style={{fontSize:22}}>{p.icon}</div><div style={{fontSize:11,marginTop:3}}>{p.name}</div></button>)}</div></SC3>
            <SC3 title="🔑 Yayın Anahtarı"><div style={{background:"#0d0d14",border:"1px solid #1a1a2e",borderRadius:2,padding:9,fontSize:10,color:"#4ade80",letterSpacing:1,wordBreak:"break-all",marginBottom:7}}>{gs.streamKey}</div><div style={{display:"flex",gap:6}}><button onClick={()=>navigator.clipboard?.writeText(gs.streamKey).then(()=>push("📋 Kopyalandı!","success"))} style={BS("#1a1a2e","#333")}>📋 Kopyala</button><button onClick={()=>{setGs(g=>({...g,streamKey:gKey()}));push("🔑 Yenilendi!","info");}} style={BS("#1a0000","#5a0000")}>🔄 Yenile</button></div></SC3>
            <SC3 title="🌐 İnternet Hızı">{ISPD.map(s=><button key={s.id} onClick={()=>{const d=s.cost-isp.cost;if(d>gs.money){push("Bakiye yetersiz!","error");return;}setGs(g=>({...g,internet:s.id,money:g.money-d}));push(`İnternet: ${s.name}`,"success");}} style={{width:"100%",padding:"7px 12px",background:gs.internet===s.id?"#0d1a2e":"#0d0d14",border:`1px solid ${gs.internet===s.id?"#2563eb":"#1a1a2e"}`,borderRadius:2,color:"#fff",cursor:"pointer",fontFamily:"inherit",textAlign:"left",display:"flex",justifyContent:"space-between",marginBottom:4,fontSize:10}}><span>{s.name}</span><span style={{color:gs.internet===s.id?"#4ade80":"#444"}}>{fmtM(s.cost)}/ay • {s.sq}</span></button>)}</SC3>
            <SC3 title="✏️ Kanal İsmi"><div style={{display:"flex",gap:8,alignItems:"center"}}><span style={{fontSize:13}}>{gs.channelName} {gs.tickStatus&&"✓"}</span><button onClick={()=>{setNewName(gs.channelName);setRenameModal(true);}} style={BS("#1a1a2e","#333")}>Değiştir</button></div>{gs.tickStatus&&<p style={{color:"#ff8800",fontSize:9,marginTop:5}}>⚠️ İsim değiştirirsen tikini kaybedersin!</p>}</SC3>
          </div>)}
        </div>

        {/* DISCORD */}
        {discOpen&&(<div style={{width:255,background:"#0d1117",borderLeft:"1px solid #1a1a2e",display:"flex",flexDirection:"column",flexShrink:0}}>
          <div style={{background:"#111118",borderBottom:"1px solid #1a1a2e",padding:"8px 12px",display:"flex",alignItems:"center",gap:7}}>
            <span style={{fontSize:16}}>💬</span>
            <div><div style={{fontWeight:700,fontSize:12}}>{gs.channelName}</div><div style={{fontSize:9,color:"#5865F2"}}>#genel • {gs.fanUsers.length} üye</div></div>
            <button onClick={()=>setDiscOpen(false)} style={{marginLeft:"auto",background:"none",border:"none",color:"#444",cursor:"pointer",fontSize:16}}>×</button>
          </div>
          <div style={{padding:"5px 9px",borderBottom:"1px solid #1a1a2e"}}>
            {["📢 duyurular","💬 genel","🎮 oyun","🎙️ yayın"].map((ch,i)=><div key={i} style={{fontSize:10,color:i===1?"#fff":"#444",padding:"3px 6px",borderRadius:2,cursor:"pointer",background:i===1?"#2a2a4e":"transparent"}}>{ch}</div>)}
          </div>
          <div ref={dcRef} style={{flex:1,overflowY:"auto",padding:"7px 7px",display:"flex",flexDirection:"column",gap:4}}>
            {gs.discMsgs.map(m=>(
              <div key={m.id} style={{background:m.isLive?"rgba(83,252,24,0.05)":m.isMod?"rgba(83,252,24,0.04)":"transparent",borderRadius:2,padding:"3px 5px",borderLeft:m.isLive?"2px solid #53FC18":m.isMod?"2px solid #4ade80":"none"}}>
                <div style={{display:"flex",gap:5,marginBottom:1}}><span style={{fontSize:10,fontWeight:700,color:m.color}}>{m.user}</span><span style={{fontSize:8,color:"#2a2a3e"}}>{m.time}</span>{m.isLive&&<span style={{fontSize:8,color:"#53FC18"}}>🔴</span>}</div>
                <div style={{fontSize:10,color:"#bbb",wordBreak:"break-word"}}>{m.text}</div>
              </div>
            ))}
          </div>
          <div style={{padding:"7px",borderTop:"1px solid #1a1a2e",display:"flex",gap:4}}>
            <input value={discIn} onChange={e=>setDiscIn(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendDisc()} placeholder="#genel'e yaz..." style={{flex:1,background:"#1a1a2e",border:"1px solid #2a2a4e",borderRadius:2,padding:"5px 7px",color:"#fff",fontSize:10,fontFamily:"inherit",outline:"none"}} />
            <button onClick={sendDisc} style={{padding:"5px 8px",background:"#5865F2",border:"none",color:"#fff",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontSize:10}}>▶</button>
          </div>
        </div>)}
      </div>

      {/* MODALS */}
      {recModal&&<MO title="🎥 Video Çekimi" onClose={()=>setRecModal(false)}><label style={L}>KATEGORİ</label><div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:5,marginBottom:12}}>{CATS.map(c=><button key={c.id} onClick={()=>setRecCat(c.id)} style={{padding:"8px 4px",background:recCat===c.id?"#1a1a3a":"#0d0d18",border:`1px solid ${recCat===c.id?"#5555cc":"#1a1a2e"}`,borderRadius:2,color:"#fff",cursor:"pointer",fontFamily:"inherit",fontSize:10}}>{c.emoji}<br/>{c.name}</button>)}</div><label style={L}>SÜRE: {recMins} DK</label><input type="range" min={2} max={60} value={recMins} onChange={e=>setRecMins(+e.target.value)} style={{width:"100%",accentColor:"#e53e3e",marginBottom:14}} /><button onClick={startRec} style={{width:"100%",padding:11,background:"#e53e3e",border:"none",color:"#fff",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontWeight:700}}>🎥 BAŞLA</button></MO>}

      {editModal&&<MO title="✂️ Editör" onClose={()=>setEditModal(false)} wide><EditWS rawVid={gs.rawVid} done={editDone} active={editActive} tl={editTL} onStep={doStep} onFinal={finalEdit} /></MO>}

      {upModal&&<MO title={`📤 ${plat.name}'a Yükle`} onClose={()=>setUpModal(false)}><label style={L}>BAŞLIK</label><input value={upTitle} onChange={e=>setUpTitle(e.target.value)} placeholder="Dikkat çekici başlık..." style={{...IN,marginBottom:10}} /><label style={L}>AÇIKLAMA</label><textarea value={upDesc} onChange={e=>setUpDesc(e.target.value)} placeholder="Açıklama..." rows={3} style={{...IN,resize:"vertical",marginBottom:12}} /><div style={{background:"#0d0d14",border:"1px solid #1a1a2e",borderRadius:2,padding:8,marginBottom:12,fontSize:10}}>Kalite: <b>{gs.editedVid?.quality}</b> • {isp.upload}Mbps • ~{isp.upT}sn</div><button onClick={startUp} disabled={!upTitle.trim()} style={{width:"100%",padding:11,background:upTitle.trim()?plat.color:"#333",border:"none",color:"#fff",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontWeight:700}}>📤 YÜKLE</button></MO>}

      {renameModal&&<MO title="✏️ Kanal İsmi" onClose={()=>setRenameModal(false)}>{gs.tickStatus&&<div style={{background:"#2d1a00",border:"1px solid #5a3a00",borderRadius:2,padding:9,marginBottom:10,fontSize:10,color:"#ff8800"}}>⚠️ 100K+ kanalda isim değiştirirsen tikini kaybedersin!</div>}<input value={newName} onChange={e=>setNewName(e.target.value)} style={{...IN,marginBottom:12,fontSize:15}} /><button onClick={applyRename} style={{width:"100%",padding:11,background:gs.tickStatus?"#aa4400":"#2563eb",border:"none",color:"#fff",cursor:"pointer",borderRadius:2,fontFamily:"inherit",fontWeight:700}}>{gs.tickStatus?"⚠️ TİKİ KAYBET VE DEĞİŞTİR":"✅ DEĞİŞTİR"}</button></MO>}

      {cmtModal&&<MO title={`💬 Yorumlar — ${cmtModal.title}`} onClose={()=>setCmtModal(null)} wide>
        {(gs.ytComments[cmtModal.id]||[]).sort((a,b)=>(b.pinned?1:0)-(a.pinned?1:0)).map(c=>(
          <div key={c.id} style={{background:c.pinned?"#0a1a2e":"#111118",border:`1px solid ${c.pinned?"#1a3a6e":"#1a1a2e"}`,borderRadius:2,padding:"9px 12px",marginBottom:5}}>
            {c.pinned&&<span style={{fontSize:9,color:"#4d96ff",display:"block",marginBottom:3}}>📌 SABİTLENDİ</span>}
            <div style={{display:"flex",gap:7,marginBottom:3}}><span style={{fontWeight:700,color:c.color,fontSize:11}}>{c.user}</span><span style={{color:"#2a2a3e",fontSize:9,marginLeft:"auto"}}>{c.time}</span></div>
            <div style={{fontSize:11,color:"#ccc",marginBottom:5}}>{c.text}</div>
            <div style={{display:"flex",gap:5}}>
              <button onClick={()=>toggleHeart(cmtModal.id,c.id)} style={{padding:"3px 9px",background:c.hearted?"#2d0a0a":"#1a1a2e",border:`1px solid ${c.hearted?"#8a0000":"#2a2a4e"}`,borderRadius:2,color:c.hearted?"#ff4444":"#555",cursor:"pointer",fontSize:10}}>{c.hearted?"❤️":"🤍"} {c.likes+(c.hearted?1:0)}</button>
              <button onClick={()=>togglePin(cmtModal.id,c.id)} style={{padding:"3px 9px",background:c.pinned?"#0a1a2e":"#1a1a2e",border:`1px solid ${c.pinned?"#2a4a8e":"#2a2a4e"}`,borderRadius:2,color:c.pinned?"#4d96ff":"#555",cursor:"pointer",fontSize:10}}>{c.pinned?"📌 Sabitlendi":"📌 Sabitle"}</button>
            </div>
          </div>
        ))}
      </MO>}

      <style>{`*{box-sizing:border-box}::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#1a1a2e}textarea{font-family:'Courier New',monospace;color:#e0e0e0}`}</style>
    </div>
  );
}

// ── EDIT WORKSPACE ─────────────────────────────────────────────────────────────
function EditWS({rawVid,done,active,tl,onStep,onFinal}){
  const cat=CATS.find(c=>c.id===rawVid?.cat);
  const q=done.reduce((s,id)=>s+(EDIT_STEPS.find(e=>e.id===id)?.q||0),10);
  return(<div>
    <div style={{background:"#111118",border:"1px solid #1a1a2e",borderRadius:2,padding:"9px 12px",marginBottom:10,fontSize:11,display:"flex",gap:10,alignItems:"center"}}><span style={{fontSize:18}}>{cat?.emoji}</span><span>{cat?.name} — {rawVid?.mins} dk</span><span style={{marginLeft:"auto",color:"#9146FF",fontWeight:700}}>Kalite: {q}</span></div>
    {tl.length>0&&<div style={{background:"#0d0d14",border:"1px solid #1a1a2e",borderRadius:2,padding:"5px 10px",marginBottom:10,display:"flex",gap:5,overflowX:"auto",flexWrap:"wrap"}}>{tl.map((t,i)=>{const s=EDIT_STEPS.find(e=>e.id===t.sid);return<span key={i} style={{fontSize:9,background:"#1a1a3a",border:"1px solid #2a2a5e",borderRadius:2,padding:"2px 7px",whiteSpace:"nowrap"}}>{s?.icon} {s?.name} <span style={{color:"#444"}}>{t.time}</span></span>;})}</div>}
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))",gap:6,marginBottom:12}}>
      {EDIT_STEPS.map(st=>{const d=done.includes(st.id),a=active===st.id;return(<button key={st.id} onClick={()=>onStep(st.id)} disabled={d||!!active} style={{padding:"10px 9px",background:d?"#0a2d0a":a?"#1a1a3a":"#111118",border:`1px solid ${d?"#1a5a1a":a?"#9146FF":"#1a1a2e"}`,borderRadius:2,color:d?"#4ade80":a?"#fff":"#bbb",cursor:d||active?"default":"pointer",fontFamily:"inherit",textAlign:"left"}}><div style={{fontSize:14,marginBottom:3}}>{d?"✅":a?"⏳":st.icon}</div><div style={{fontSize:11,fontWeight:600}}>{st.name}</div><div style={{fontSize:9,color:d?"#4ade80":a?"#888":"#444",marginTop:2}}>{a?"İşleniyor...":d?"Tamamlandı":`+${st.q} kalite`}</div>{!d&&!a&&<div style={{fontSize:8,color:"#333",marginTop:1}}>~{(st.time*.3).toFixed(1)}sn</div>}</button>);})}
    </div>
    <div style={{display:"flex",gap:8,alignItems:"center"}}>
      <div style={{flex:1,background:"#0d0d14",border:"1px solid #1a1a2e",borderRadius:2,padding:"7px 12px",fontSize:10}}>{done.length}/{EDIT_STEPS.length} adım • Kalite: <b style={{color:"#9146FF"}}>{q}</b></div>
      <button onClick={onFinal} disabled={!done.length} style={{padding:"8px 18px",background:done.length?"#9146FF":"#222",border:"none",color:"#fff",cursor:done.length?"pointer":"not-allowed",borderRadius:2,fontFamily:"inherit",fontWeight:700,fontSize:12}}>✅ TAMAMLA</button>
    </div>
  </div>);
}

// ── MINI COMPONENTS ────────────────────────────────────────────────────────────
function MO({title,children,onClose,wide}){return(<div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.88)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,padding:14}} onClick={onClose}><div style={{background:"#111118",border:"1px solid #2a2a3e",borderRadius:4,padding:18,width:"100%",maxWidth:wide?680:440,maxHeight:"90vh",overflowY:"auto"}} onClick={e=>e.stopPropagation()}><div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}><span style={{fontWeight:700,fontSize:13}}>{title}</span><button onClick={onClose} style={{background:"none",border:"none",color:"#444",cursor:"pointer",fontSize:20}}>×</button></div>{children}</div></div>);}
function GB({l,onClick,disabled,color}){return (<button onClick={onClick} disabled={disabled} style={{padding:"9px 6px",background:disabled?"#0d0d0d":"#111118",border:`1px solid ${disabled?"#111":color||"#333"}`,borderRadius:2,color:disabled?"#222":"#fff",cursor:disabled?"not-allowed":"pointer",fontSize:10,fontFamily:"'Courier New',monospace"}}>{l}</button>);}
function PB({label,val,color}){return (<div style={{marginBottom:9}}>{label&&<div style={{fontSize:9,color:"#666",marginBottom:3}}>{label} {Math.floor(val)}%</div>}<div style={{height:4,background:"#1a1a2e",borderRadius:2,overflow:"hidden"}}><div style={{height:"100%",width:`${val}%`,background:color,transition:"width 0.15s"}} /></div></div>);}
function ST({children}){return (<div style={{fontSize:9,letterSpacing:1,color:"#333",marginBottom:9}}>{children}</div>);}
function SC2({title,children}){return (<div style={{background:"#0d0d18",border:"1px solid #1a1a2e",borderRadius:2,padding:12,marginBottom:10}}><div style={{fontSize:9,letterSpacing:1,color:"#444",marginBottom:8}}>{title}</div>{children}</div>);}
function SC3({title,children}){return (<div style={{background:"#111118",border:"1px solid #1a1a2e",borderRadius:2,padding:14,marginBottom:9}}><div style={{fontSize:9,letterSpacing:1,color:"#333",marginBottom:10}}>{title}</div>{children}</div>);}
const BS=(bg,br)=>({padding:"5px 11px",background:bg,border:`1px solid ${br}`,borderRadius:2,color:"#fff",cursor:"pointer",fontFamily:"'Courier New',monospace",fontSize:10});
const BS2={padding:"2px 6px",background:"#1a1a2e",border:"1px solid #2a2a4e",borderRadius:2,color:"#777",cursor:"pointer",fontFamily:"'Courier New',monospace",fontSize:9};
const IN={width:"100%",background:"#0d0d18",border:"1px solid #2a2a3e",borderRadius:2,padding:"9px 10px",color:"#fff",fontSize:12,fontFamily:"'Courier New',monospace",outline:"none",boxSizing:"border-box"};
const SEL={width:"100%",background:"#0d0d18",border:"1px solid #1a1a2e",borderRadius:2,padding:"7px 9px",color:"#fff",fontFamily:"'Courier New',monospace",fontSize:11,outline:"none"};
const L={display:"block",fontSize:9,letterSpacing:1,color:"#444",marginBottom:5};
